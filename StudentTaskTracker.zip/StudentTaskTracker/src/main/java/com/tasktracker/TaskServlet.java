/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.tasktracker;

import java.io.*;
import java.util.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;

@WebServlet("/TaskServlet")
public class TaskServlet extends HttpServlet {

    ArrayList<HashMap<String, String>> tasks = new ArrayList<>();

   
    private String filePath = "C:\\Users\\Public\\Documents\\Tasks.txt";

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String studentName = request.getParameter("studentName");
        String moduleName = request.getParameter("moduleName");
        String taskScore = request.getParameter("taskScore");

        HashMap<String, String> task = new HashMap<>();

        task.put("studentName", studentName);
        task.put("moduleName", moduleName);
        task.put("taskScore", taskScore);

        tasks.add(task);

        
        FileWriter fw = new FileWriter(filePath, true);
        fw.write(studentName + " - " + moduleName + " - " + taskScore + "\n");
        fw.close();

        response.sendRedirect("TaskServlet");
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        out.println("<html><head>");
        out.println("<title>Stored Tasks</title>");

        out.println("<style>");
        out.println("body{font-family:Arial;background:#f4f4f4;text-align:center;}");
        out.println("table{margin:auto;border-collapse:collapse;width:60%;background:white;}");
        out.println("th,td{padding:12px;border:1px solid #ddd;}");
        out.println("th{background:#007BFF;color:white;}");
        out.println("tr:nth-child(even){background:#f2f2f2;}");
        out.println("</style>");

        out.println("</head><body>");
        out.println("<h2>Stored Student Tasks</h2>");

        out.println("<table>");
        out.println("<tr><th>Student</th><th>Module</th><th>Score</th></tr>");

        File file = new File(filePath);

        if(file.exists()){

            BufferedReader br = new BufferedReader(new FileReader(file));
            String line;

            while((line = br.readLine()) != null){

                String[] data = line.split(" - ");

                out.println("<tr>");
                out.println("<td>" + data[0] + "</td>");
                out.println("<td>" + data[1] + "</td>");
                out.println("<td>" + data[2] + "</td>");
                out.println("</tr>");
            }

            br.close();
        }

        out.println("</table>");

        out.println("<br><a href='index.html'>Add New Task</a>");

        out.println("</body></html>");
    }
}