// ============================================================
// FINANCIAL ADVISOR AI - DASHBOARD.JS
// COMPLETE FIXED VERSION
// ============================================================

import {
    auth,
    db,
    storage
} from "./firebase.js";

import {
    onAuthStateChanged,
    signOut
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-auth.js";

import {
    doc,
    getDoc,
    addDoc,
    collection,
    getDocs,
    query,
    where,
    serverTimestamp
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore.js";

import {
    ref,
    uploadBytes,
    getDownloadURL
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-storage.js";

import {
    getDocument,
    GlobalWorkerOptions
} from "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/4.10.38/pdf.min.mjs";


// ============================================================
// CONFIGURATION
// ============================================================

// IMPORTANT:
// Your Node.js backend is running on port 3000.
//
// Do NOT put your OpenAI API key here.
// The API key stays inside .env on the backend.

const API_BASE_URL = "http://localhost:3000";

const API_URL = `${API_BASE_URL}/api/chat`;

const AI_INSIGHTS_URL = `${API_BASE_URL}/api/ai/insights`;
const AI_HEALTH_SCORE_URL = `${API_BASE_URL}/api/ai/health-score`;
const AI_FORECAST_URL = `${API_BASE_URL}/api/ai/forecast`;
const AI_ANOMALIES_URL = `${API_BASE_URL}/api/ai/anomalies`;
const AI_CATEGORIZE_URL = `${API_BASE_URL}/api/ai/categorize`;
const AI_GOAL_PLAN_URL = `${API_BASE_URL}/api/ai/goal-plan`;


// ============================================================
// PDF.JS WORKER
// ============================================================

GlobalWorkerOptions.workerSrc =
    "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/4.10.38/pdf.worker.min.mjs";


// ============================================================
// GLOBAL STATE
// ============================================================

let currentUser = null;

let currentProfile = {};

let lastFinancialResult = null;

let allFinancialTransactions = [];


// ============================================================
// VOICE + LANGUAGE STATE
// ============================================================

const SA_LANGUAGES = {

    auto: {
        name: "Auto detect",
        speech: "en-ZA",
        tts: ["en-ZA", "en-GB", "en-US"]
    },

    en: {
        name: "English",
        speech: "en-ZA",
        tts: ["en-ZA", "en-GB", "en-US"]
    },

    af: {
        name: "Afrikaans",
        speech: "af-ZA",
        tts: ["af-ZA", "af"]
    },

    zu: {
        name: "isiZulu",
        speech: "zu-ZA",
        tts: ["zu-ZA", "zu"]
    },

    xh: {
        name: "isiXhosa",
        speech: "xh-ZA",
        tts: ["xh-ZA", "xh"]
    },

    st: {
        name: "Sesotho",
        speech: "st-ZA",
        tts: ["st-ZA", "st"]
    },

    tn: {
        name: "Setswana",
        speech: "tn-ZA",
        tts: ["tn-ZA", "tn"]
    },

    nso: {
        name: "Sepedi",
        speech: "nso-ZA",
        tts: ["nso-ZA", "nso"]
    },

    ss: {
        name: "siSwati",
        speech: "ss-ZA",
        tts: ["ss-ZA", "ss"]
    },

    ve: {
        name: "Tshivenda",
        speech: "ve-ZA",
        tts: ["ve-ZA", "ve"]
    },

    ts: {
        name: "itsonga",
        speech: "ts-ZA",
        tts: ["ts-ZA", "ts"]
    },

    nr: {
        name: "isiNdebele",
        speech: "nr-ZA",
        tts: ["nr-ZA", "nr"]
    }

};


let selectedLanguage =
    localStorage.getItem(
        "financialAdvisorLanguage"
    ) || "auto";


let speechRecognition = null;

let isListening = false;

let currentUtterance = null;

let lastVoiceMessage = false;

// ============================================================
// LANGUAGE DETECTION
// ============================================================

function detectLanguageFromText(text) {

    const value =
        String(text || "").toLowerCase();

    if (!value) {
        return "en";
    }

    const patterns = {

        zu:
            /\b(ngicela|ngiyabonga|kanjani|imali|yami|ngifuna|ukuthi|ngingakwazi|nging|kakhulu)\b/,

        xh:
            /\b(ndicela|enkosi|imali|yam|ndifuna|ukuba|ndingakwazi|kakhulu)\b/,

        st:
            /\b(ke kopa|kea leboha|tjhelete|chelete|ke batla|hore|jwang)\b/,

        tn:
            /\b(ke kopa|ke a leboga|madi|tshelete|ke batla|gore|jang)\b/,

        nso:
            /\b(hle|ke kgopela|ke a leboga|tjhelete|madi|ke nyaka|gore)\b/,

        ss:
            /\b(ngiyacela|ngiyabonga|imali|yami|ngifuna|kutsi|kakhulu)\b/,

        ve:
            /\b(ndapota|ndo livhuwa|mali|yanga|ndi toda|uri|hani)\b/,

        ts:
            /\b(ndzi kombela|ndza khensa|mali|ya mina|ndzi lava|leswaku|njhani)\b/,

        af:
            /\b(asseblief|dankie|geld|myne|ek wil|hoeveel|waarom|begroting)\b/,

        nr:
            /\b(ngiyacela|ngiyathokoza|imali|yami|ngifuna|ukuthi|kakhulu)\b/
    };


    for (
        const [code, pattern]
        of Object.entries(patterns)
    ) {

        if (pattern.test(value)) {

            return code;

        }

    }


    return "en";

}


// ============================================================
// LANGUAGE INSTRUCTION FOR AI
// ============================================================

function languageInstruction(language) {

    const config =
        SA_LANGUAGES[language] ||
        SA_LANGUAGES.auto;


    if (language === "auto") {

        return (
            "Detect the language of the user's message. " +
            "Reply in the same language when possible. " +
            "Supported South African languages include " +
            "English, Afrikaans, isiZulu, isiXhosa, Sesotho, " +
            "Setswana, Sepedi, siSwati, Tshivenda, " +
            "itsonga and isiNdebele."
        );

    }


    return (
        `Reply ONLY in ${config.name}. ` +
        "Keep financial numbers and South African Rand (R) " +
        "amounts accurate. Do not change transaction amounts."
    );

}


// ============================================================
// STOP SPEAKING
// ============================================================

function stopSpeaking() {

    if (
        "speechSynthesis" in window
    ) {

        window.speechSynthesis.cancel();

    }


    currentUtterance = null;

}


// ============================================================
// TEXT TO SPEECH
// ============================================================

function speakText(
    text,
    language = selectedLanguage
) {

    if (
        !("speechSynthesis" in window)
    ) {

        console.warn(
            "Speech synthesis is not supported."
        );

        return;

    }


    stopSpeaking();


    const plain =
        String(text || "")
            .replace(
                /<[^>]*>/g,
                " "
            )
            .replace(
                /[*_#]/g,
                ""
            )
            .replace(
                /\s+/g,
                " "
            )
            .trim();


    if (!plain) {

        return;

    }


    const detected =
        language === "auto"
            ? detectLanguageFromText(plain)
            : language;


    const config =
        SA_LANGUAGES[detected] ||
        SA_LANGUAGES.en;


    const voices =
        window.speechSynthesis.getVoices();


    let voice = null;


    for (
        const code of config.tts
    ) {

        voice =
            voices.find(
                v =>
                    String(v.lang || "")
                        .toLowerCase() ===
                    code.toLowerCase()
            ) ||

            voices.find(
                v =>
                    String(v.lang || "")
                        .toLowerCase()
                        .startsWith(
                            code
                                .toLowerCase()
                                .split("-")[0]
                        )
            );


        if (voice) {

            break;

        }

    }


    currentUtterance =
        new SpeechSynthesisUtterance(
            plain
        );


    currentUtterance.lang =
        config.speech;


    currentUtterance.rate =
        0.95;


    currentUtterance.pitch =
        1;


    if (voice) {

        currentUtterance.voice =
            voice;

    }


    currentUtterance.onend =
        () => {

            currentUtterance =
                null;

        };


    currentUtterance.onerror =
        () => {

            currentUtterance =
                null;

        };


    window.speechSynthesis.speak(
        currentUtterance
    );

}


// ============================================================
// CREATE VOICE CONTROLS
// ============================================================

function createVoiceControls() {

    if (
        !chatbot ||
        document.getElementById(
            "voiceControls"
        )
    ) {

        return;

    }


    const controls =
        document.createElement(
            "div"
        );


    controls.id =
        "voiceControls";


    controls.style.cssText =
        `
        display:flex;
        gap:8px;
        align-items:center;
        flex-wrap:wrap;
        margin:8px 0;
        padding:8px;
        border-radius:10px;
        background:rgba(0,0,0,.04);
        `;


    controls.innerHTML =
        `

        <button
            type="button"
            id="voiceInputButton"
            title="Speak your question"
            style="
                cursor:pointer;
                border:0;
                border-radius:8px;
                padding:8px 12px;
            "
        >
            🎤 Speak
        </button>


        <select
            id="languageSelect"
            title="Choose chatbot language"
            style="
                padding:8px;
                border-radius:8px;
                border:1px solid #ccc;
            "
        >

            ${Object.entries(
                SA_LANGUAGES
            )
                .map(
                    ([code, item]) =>
                        `
                        <option value="${code}">
                            ${item.name}
                        </option>
                        `
                )
                .join("")}

        </select>


        <button
            type="button"
            id="stopVoiceButton"
            title="Stop spoken answer"
            style="
                cursor:pointer;
                border:0;
                border-radius:8px;
                padding:8px 12px;
            "
        >
            🔇 Stop
        </button>


        <span
            id="voiceStatus"
            style="
                font-size:12px;
                opacity:.75;
            "
        ></span>

        `;


    chatbot.prepend(
        controls
    );


    const select =
        document.getElementById(
            "languageSelect"
        );


    if (select) {

        select.value =
            selectedLanguage;

    }


    select?.addEventListener(
        "change",
        () => {

            selectedLanguage =
                select.value;


            localStorage.setItem(
                "financialAdvisorLanguage",
                selectedLanguage
            );


            if (speechRecognition) {

                speechRecognition.lang =
                    (
                        SA_LANGUAGES[
                            selectedLanguage
                        ] ||
                        SA_LANGUAGES.auto
                    ).speech;

            }


            const status =
                document.getElementById(
                    "voiceStatus"
                );


            if (status) {

                status.textContent =
                    `Language: ${
                        (
                            SA_LANGUAGES[
                                selectedLanguage
                            ] ||
                            SA_LANGUAGES.auto
                        ).name
                    }`;

            }

        }
    );


    document
        .getElementById(
            "stopVoiceButton"
        )
        ?.addEventListener(
            "click",
            stopSpeaking
        );


    document
        .getElementById(
            "voiceInputButton"
        )
        ?.addEventListener(
            "click",
            startVoiceInput
        );


    setupSpeechRecognition();

}


// ============================================================
// SPEECH RECOGNITION
// ============================================================

function setupSpeechRecognition() {

    const Recognition =
        window.SpeechRecognition ||
        window.webkitSpeechRecognition;


    const button =
        document.getElementById(
            "voiceInputButton"
        );


    const status =
        document.getElementById(
            "voiceStatus"
        );


    if (!Recognition) {

        if (button) {

            button.disabled =
                true;

            button.title =
                "Speech recognition is not supported by this browser.";

        }


        if (status) {

            status.textContent =
                "Voice input unavailable";

        }


        return;

    }


    speechRecognition =
        new Recognition();


    speechRecognition.continuous =
        false;


    speechRecognition.interimResults =
        false;


    speechRecognition.maxAlternatives =
        1;


    speechRecognition.lang =
        (
            SA_LANGUAGES[
                selectedLanguage
            ] ||
            SA_LANGUAGES.auto
        ).speech;


    speechRecognition.onstart =
        () => {

            isListening =
                true;


            if (button) {

                button.textContent =
                    "⏹️ Listening...";

            }


            if (status) {

                status.textContent =
                    "Speak now...";

            }

        };


    speechRecognition.onresult =
        event => {

            const transcript =
                event.results?.[0]?.[0]
                    ?.transcript
                    ?.trim() || "";


            if (!transcript) {

                return;

            }


            if (chatInput) {

                chatInput.value =
                    transcript;

            }


            lastVoiceMessage =
                true;


            if (status) {

                status.textContent =
                    `Heard: ${transcript}`;

            }


            sendMessage();

        };


    speechRecognition.onerror =
        event => {

            console.error(
                "VOICE INPUT ERROR:",
                event.error
            );


            if (status) {

                status.textContent =
                    `Voice input error: ${event.error}`;

            }

        };


    speechRecognition.onend =
        () => {

            isListening =
                false;


            if (button) {

                button.textContent =
                    "🎤 Speak";

            }

        };

}


// ============================================================
// START VOICE INPUT
// ============================================================

function startVoiceInput() {

    if (!speechRecognition) {

        setupSpeechRecognition();


        if (!speechRecognition) {

            return;

        }

    }


    if (isListening) {

        speechRecognition.stop();

        return;

    }


    stopSpeaking();


    speechRecognition.lang =
        (
            SA_LANGUAGES[
                selectedLanguage
            ] ||
            SA_LANGUAGES.auto
        ).speech;


    try {

        speechRecognition.start();

    } catch (error) {

        console.error(
            "VOICE START ERROR:",
            error
        );

    }

}


if (
    "speechSynthesis" in window
) {

    window.speechSynthesis.onvoiceschanged =
        () => {};

}


// ============================================================
// DOM HELPER
// ============================================================

function getElement(id) {

    return document.getElementById(id);

}


// ============================================================
// AUTHENTICATION
// ============================================================

onAuthStateChanged(auth, async (user) => {

    if (!user) {

        window.location.href = "login.html";

        return;

    }

    currentUser = user;


    try {

        await loadUserProfile(user.uid);

    } catch (error) {

        console.error(
            "PROFILE LOAD ERROR:",
            error
        );

    }


    try {

        await loadFinancialHistory(user.uid);

    } catch (error) {

        console.error(
            "HISTORY LOAD ERROR:",
            error
        );

    }

});


// ============================================================
// USER PROFILE
// ============================================================

async function loadUserProfile(uid) {

    try {

        const userRef =
            doc(
                db,
                "users",
                uid
            );


        const snapshot =
            await getDoc(
                userRef
            );


        if (snapshot.exists()) {

            currentProfile =
                snapshot.data() || {};

        } else {

            currentProfile = {};

        }


        const firstName =
            currentProfile.firstName ||
            userDisplayName(currentUser) ||
            "there";


        const lastName =
            currentProfile.lastName ||
            "";


        const fullName =
            `${firstName} ${lastName}`.trim();


        const welcomeName =
            getElement("welcomeName");


        if (welcomeName) {

            welcomeName.textContent =
                `Hi ${firstName} 👋`;

        }


        const profileName =
            getElement("profileName");


        if (profileName) {

            profileName.textContent =
                fullName;

        }


        const profileEmail =
            getElement("profileEmail");


        if (profileEmail) {

            profileEmail.textContent =
                currentProfile.email ||
                currentUser?.email ||
                "";

        }


        const botGreeting =
            getElement("botGreeting");


        if (botGreeting) {

            botGreeting.textContent =
                `Hi ${firstName} 👋 I'm your Financial Advisor. ` +
                `I can analyse your statements, answer general questions, ` +
                `explain your spending and help you plan your money.`;

        }

    } catch (error) {

        console.error(
            "PROFILE ERROR:",
            error
        );

        currentProfile = {};

    }

}


function userDisplayName(user) {

    if (!user) {

        return "";

    }

    return user.displayName || "";

}


// ============================================================
// LOGOUT
// ============================================================

const logoutButton =
    getElement("logoutButton");


if (logoutButton) {

    logoutButton.addEventListener(
        "click",
        async () => {

            logoutButton.disabled = true;


            try {

                await signOut(auth);

                window.location.href =
                    "login.html";

            } catch (error) {

                console.error(
                    "LOGOUT ERROR:",
                    error
                );


                alert(
                    "Unable to log out. Please try again."
                );


                logoutButton.disabled = false;

            }

        }
    );

}


// ============================================================
// MAIN STATEMENT UPLOAD
// ============================================================

const uploadButton =
    getElement("uploadButton");


if (uploadButton) {

    uploadButton.addEventListener(
        "click",
        uploadStatement
    );

}


async function uploadStatement() {

    const fileInput =
        getElement("statementFile");

    const status =
        getElement("uploadStatus");

    const analysis =
        getElement("analysis");

    const file =
        fileInput?.files?.[0];


    if (!file) {

        setStatus(
            status,
            "❌ Please select a PDF or CSV statement first."
        );

        return;

    }


    if (!currentUser) {

        setStatus(
            status,
            "❌ Your session has expired. Please log in again."
        );

        return;

    }


    if (!isValidStatementFile(file)) {

        setStatus(
            status,
            "❌ Please upload a valid PDF or CSV bank statement."
        );

        return;

    }


    try {

        uploadButton.disabled = true;


        setStatus(
            status,
            "⏳ Reading your statement..."
        );


        if (analysis) {

            analysis.innerHTML =
                "🔎 Analysing transactions...";

        }


        let result;


        if (isPDF(file)) {

            result =
                await analysePDF(file);

        } else {

            result =
                await analyseCSV(file);

        }


        if (
            !result ||
            !Array.isArray(result.transactions) ||
            result.transactions.length === 0
        ) {

            throw new Error(
                "No transactions were detected. Make sure your statement contains transaction dates, descriptions and amounts."
            );

        }


        lastFinancialResult =
            result;


        allFinancialTransactions =
            removeDuplicateTransactions(
                [
                    ...allFinancialTransactions,
                    ...result.transactions
                ]
            );


        updateFinancialDashboard(
            result
        );


        generateFinancialFeedback(
            result
        );


        runAutomaticAIFeatures(
            result
        );


        setStatus(
            status,
            "✅ Statement analysed successfully."
        );


        try {

            await saveStatementToFirebase(
                result,
                file
            );


            setStatus(
                status,
                "✅ Statement analysed and saved successfully."
            );

        } catch (firebaseError) {

            console.error(
                "FIREBASE SAVE ERROR:",
                firebaseError
            );


            setStatus(
                status,
                "✅ Statement analysed. ⚠️ Firebase could not save the statement."
            );

        }

    } catch (error) {

        console.error(
            "STATEMENT ERROR:",
            error
        );


        setStatus(
            status,
            `❌ ${error.message || "Unable to analyse statement."}`
        );


        if (analysis) {

            analysis.innerHTML =
                "❌ Unable to analyse this statement.";

        }

    } finally {

        uploadButton.disabled = false;

    }

}


// ============================================================
// SAVE STATEMENT TO FIREBASE
// ============================================================

async function saveStatementToFirebase(
    result,
    file
) {

    if (!currentUser) {

        throw new Error(
            "User is not authenticated."
        );

    }


    if (!storage) {

        throw new Error(
            "Firebase Storage is not configured."
        );

    }


    const safeFileName =
        sanitizeFileName(
            file.name
        );


    const filePath =
        `statements/${currentUser.uid}/${Date.now()}_${safeFileName}`;


    const fileRef =
        ref(
            storage,
            filePath
        );


    await uploadBytes(
        fileRef,
        file
    );


    const downloadURL =
        await getDownloadURL(
            fileRef
        );


    await addDoc(
        collection(
            db,
            "statements"
        ),
        {

            userId:
                currentUser.uid,

            fileName:
                file.name,

            filePath,

            downloadURL,

            uploadedAt:
                serverTimestamp(),

            source:
                "dashboard",

            totalIncome:
                Number(
                    result.totalIncome || 0
                ),

            totalExpenses:
                Number(
                    result.totalExpenses || 0
                ),

            balance:
                Number(
                    result.balance || 0
                ),

            categories:
                result.categories || {},

            transactions:
                result.transactions || []

        }
    );

}


// ============================================================
// LOAD FINANCIAL HISTORY
// ============================================================

async function loadFinancialHistory(uid) {

    if (!uid) {

        return;

    }


    try {

        const statementsRef =
            collection(
                db,
                "statements"
            );


        const statementsQuery =
            query(
                statementsRef,
                where(
                    "userId",
                    "==",
                    uid
                )
            );


        const snapshot =
            await getDocs(
                statementsQuery
            );


        const historyTransactions = [];


        snapshot.forEach(
            item => {

                const data =
                    item.data() || {};


                if (
                    Array.isArray(
                        data.transactions
                    )
                ) {

                    historyTransactions.push(
                        ...data.transactions
                    );

                }

            }
        );


        if (
            historyTransactions.length === 0
        ) {

            return;

        }


        allFinancialTransactions =
            removeDuplicateTransactions(
                [
                    ...allFinancialTransactions,
                    ...historyTransactions
                ]
            );


        const latest =
            getLatestTransaction(
                allFinancialTransactions
            );


        if (latest) {

            lastFinancialResult = {

                transactions:
                    allFinancialTransactions,

                totalIncome:
                    allFinancialTransactions
                        .filter(
                            t =>
                                t.type === "income"
                        )
                        .reduce(
                            (
                                total,
                                t
                            ) =>
                                total +
                                Number(
                                    t.amount || 0
                                ),
                            0
                        ),

                totalExpenses:
                    allFinancialTransactions
                        .filter(
                            t =>
                                t.type === "expense"
                        )
                        .reduce(
                            (
                                total,
                                t
                            ) =>
                                total +
                                Number(
                                    t.amount || 0
                                ),
                            0
                        ),

                balance:
                    Number(
                        latest.balance || 0
                    ),

                categories:
                    calculateCategories(
                        allFinancialTransactions
                    )

            };

        }


        const current =
            getMonthlyFinancialData(0);


        if (
            current.transactions > 0
        ) {

            updateDashboardFromMonthlyData(
                current
            );

        } else if (lastFinancialResult) {

            updateFinancialDashboard(
                lastFinancialResult
            );

        }


        if (lastFinancialResult) {

            runAutomaticAIFeatures(
                lastFinancialResult
            );

        }

    } catch (error) {

        console.error(
            "FINANCIAL HISTORY ERROR:",
            error
        );

    }

}


// ============================================================
// LATEST TRANSACTION
// ============================================================

function getLatestTransaction(
    transactions
) {

    if (
        !transactions ||
        transactions.length === 0
    ) {

        return null;

    }


    const sorted =
        [...transactions]
            .sort(
                (a, b) => {

                    const dateA =
                        parseFinancialDate(
                            a.date
                        );

                    const dateB =
                        parseFinancialDate(
                            b.date
                        );


                    if (!dateA) return 1;

                    if (!dateB) return -1;


                    return (
                        dateB.getTime() -
                        dateA.getTime()
                    );

                }
            );


    return sorted[0] || null;

}


// ============================================================
// PDF ANALYSIS
// ============================================================

async function analysePDF(file) {

    const arrayBuffer =
        await file.arrayBuffer();


    const pdf =
        await getDocument(
            {
                data: arrayBuffer
            }
        ).promise;


    const allLines = [];


    for (
        let pageNumber = 1;
        pageNumber <= pdf.numPages;
        pageNumber++
    ) {

        const page =
            await pdf.getPage(
                pageNumber
            );


        const textContent =
            await page.getTextContent();


        const lines =
            convertPDFTextToLines(
                textContent
            );


        allLines.push(
            ...lines
        );

    }


    return parseStatementLines(
        allLines
    );

}


// ============================================================
// PDF TEXT TO LINES
// ============================================================

function convertPDFTextToLines(
    textContent
) {

    const rows = {};


    for (
        const item
        of textContent.items
    ) {

        if (
            !item.str ||
            !item.str.trim()
        ) {

            continue;

        }


        const x =
            Number(
                item.transform?.[4] || 0
            );


        const y =
            Math.round(
                Number(
                    item.transform?.[5] || 0
                )
            );


        const key =
            String(y);


        if (!rows[key]) {

            rows[key] = [];

        }


        rows[key].push({

            x,

            text:
                item.str
                    .replace(
                        /\s+/g,
                        " "
                    )
                    .trim()

        });

    }


    const sortedRows =
        Object.keys(rows)
            .map(Number)
            .sort(
                (a, b) =>
                    b - a
            );


    return sortedRows.map(
        y => {

            return rows[y]
                .sort(
                    (a, b) =>
                        a.x - b.x
                )
                .map(
                    item =>
                        item.text
                )
                .join(" ")
                .replace(
                    /\s+/g,
                    " "
                )
                .trim();

        }
    );

}


// ============================================================
// PDF STATEMENT PARSER
// ============================================================

function parseStatementLines(
    lines
) {

    const transactions = [];

    let totalIncome = 0;

    let totalExpenses = 0;

    let latestBalance = 0;


    for (
        const rawLine
        of lines
    ) {

        const line =
            String(rawLine || "")
                .replace(
                    /\s+/g,
                    " "
                )
                .trim();


        if (!line) {

            continue;

        }


        const dateMatch =
            extractDateFromLine(
                line
            );


        if (!dateMatch) {

            continue;

        }


        const date =
            dateMatch.date;


        const remainder =
            dateMatch.remainder;


        const moneyMatches =
            extractMoneyValues(
                remainder
            );


        if (
            moneyMatches.length === 0
        ) {

            continue;

        }


        let description =
            remainder
                .replace(
                    /(?:R\s*)?\(?-?[\d\s,]+\.\d{2}\)?/gi,
                    " "
                )
                .replace(
                    /\b(?:DR|CR)\b/gi,
                    " "
                )
                .replace(
                    /\s+/g,
                    " "
                )
                .trim();


        if (!description) {

            description =
                "Bank transaction";

        }


        let amount = 0;

        let balance =
            latestBalance;


        if (
            moneyMatches.length >= 2
        ) {

            const amountValue =
                moneyToNumber(
                    moneyMatches[
                        moneyMatches.length - 2
                    ]
                );


            const balanceValue =
                moneyToNumber(
                    moneyMatches[
                        moneyMatches.length - 1
                    ]
                );


            amount =
                Math.abs(
                    amountValue
                );


            balance =
                balanceValue;

        } else {

            amount =
                Math.abs(
                    moneyToNumber(
                        moneyMatches[0]
                    )
                );

        }


        if (
            amount <= 0
        ) {

            continue;

        }


        latestBalance =
            balance;


        const upper =
            description.toUpperCase();


        const type =
            isIncomeDescription(
                upper
            )
                ? "income"
                : "expense";


        const category =
            determineCategory(
                upper
            );


        const transaction = {

            date,

            description,

            amount:
                roundMoney(
                    amount
                ),

            type,

            category,

            balance:
                roundMoney(
                    balance
                )

        };


        transactions.push(
            transaction
        );


        if (
            type === "income"
        ) {

            totalIncome +=
                amount;

        } else {

            totalExpenses +=
                amount;

        }

    }


    return {

        transactions,

        totalIncome:
            roundMoney(
                totalIncome
            ),

        totalExpenses:
            roundMoney(
                totalExpenses
            ),

        balance:
            roundMoney(
                latestBalance
            ),

        categories:
            calculateCategories(
                transactions
            )

    };

}


// ============================================================
// DATE EXTRACTION
// ============================================================

function extractDateFromLine(
    line
) {

    if (!line) {

        return null;

    }


    const patterns = [

        /^(\d{4}-\d{2}-\d{2})\s+(.+)$/,

        /^(\d{2}\/\d{2}\/\d{4})\s+(.+)$/,

        /^(\d{2}-\d{2}-\d{4})\s+(.+)$/,

        /^(\d{2}\/\d{2}\/\d{2})\s+(.+)$/,

        /^(\d{2}-\d{2}-\d{2})\s+(.+)$/,

        /^(\d{1,2}\s+[A-Za-z]{3}\s+\d{4})\s+(.+)$/,

        /^(\d{1,2}\s+[A-Za-z]+\s+\d{4})\s+(.+)$/

    ];


    for (
        const pattern
        of patterns
    ) {

        const match =
            line.match(
                pattern
            );


        if (match) {

            return {

                date:
                    normalizeDateString(
                        match[1]
                    ),

                remainder:
                    match[2]

            };

        }

    }


    return null;

}


// ============================================================
// NORMALIZE DATE
// ============================================================

function normalizeDateString(
    value
) {

    const text =
        String(value || "")
            .trim();


    let match;


    match =
        text.match(
            /^(\d{2})\/(\d{2})\/(\d{2})$/
        );


    if (match) {

        let year =
            Number(
                match[3]
            );


        year =
            year < 70
                ? 2000 + year
                : 1900 + year;


        return `${year}-${match[2]}-${match[1]}`;

    }


    match =
        text.match(
            /^(\d{2})-(\d{2})-(\d{2})$/
        );


    if (match) {

        let year =
            Number(
                match[3]
            );


        year =
            year < 70
                ? 2000 + year
                : 1900 + year;


        return `${year}-${match[2]}-${match[1]}`;

    }


    match =
        text.match(
            /^(\d{2})\/(\d{2})\/(\d{4})$/
        );


    if (match) {

        return `${match[3]}-${match[2]}-${match[1]}`;

    }


    match =
        text.match(
            /^(\d{2})-(\d{2})-(\d{4})$/
        );


    if (match) {

        return `${match[3]}-${match[2]}-${match[1]}`;

    }


    match =
        text.match(
            /^(\d{1,2})\s+([A-Za-z]+)\s+(\d{4})$/
        );


    if (match) {

        const months = {

            jan: 1,
            january: 1,

            feb: 2,
            february: 2,

            mar: 3,
            march: 3,

            apr: 4,
            april: 4,

            may: 5,

            jun: 6,
            june: 6,

            jul: 7,
            july: 7,

            aug: 8,
            august: 8,

            sep: 9,
            sept: 9,
            september: 9,

            oct: 10,
            october: 10,

            nov: 11,
            november: 11,

            dec: 12,
            december: 12

        };


        const month =
            months[
                match[2].toLowerCase()
            ];


        if (month) {

            return `${match[3]}-${String(month).padStart(2, "0")}-${String(Number(match[1])).padStart(2, "0")}`;

        }

    }


    return text;

}


// ============================================================
// MONEY EXTRACTION
// ============================================================

function extractMoneyValues(
    text
) {

    if (!text) {

        return [];

    }


    const matches =
        text.match(
            /(?:R\s*)?(?:-|\()?[\d\s,]+(?:\.\d{2})(?:\))?/gi
        );


    return matches || [];

}


// ============================================================
// CSV ANALYSIS
// ============================================================

async function analyseCSV(file) {

    const text =
        await file.text();


    const lines =
        text
            .replace(
                /^\uFEFF/,
                ""
            )
            .split(
                /\r?\n/
            )
            .map(
                line =>
                    line.trim()
            )
            .filter(Boolean);


    if (
        lines.length < 2
    ) {

        return emptyFinancialResult();

    }


    const headers =
        parseCSVLine(
            lines[0]
        )
            .map(
                value =>
                    normalizeHeader(
                        value
                    )
            );


    const dateIndex =
        findColumn(
            headers,
            [
                "date",
                "transaction date",
                "trans date",
                "value date",
                "posting date"
            ]
        );


    const descriptionIndex =
        findColumn(
            headers,
            [
                "description",
                "details",
                "transaction",
                "narration",
                "merchant",
                "reference"
            ]
        );


    const amountIndex =
        findColumn(
            headers,
            [
                "amount",
                "transaction amount",
                "value"
            ]
        );


    const debitIndex =
        findColumn(
            headers,
            [
                "debit",
                "withdrawal",
                "withdrawals",
                "debits"
            ]
        );


    const creditIndex =
        findColumn(
            headers,
            [
                "credit",
                "deposit",
                "deposits",
                "credits"
            ]
        );


    const balanceIndex =
        findColumn(
            headers,
            [
                "balance",
                "closing balance",
                "running balance"
            ]
        );


    const transactions = [];

    let totalIncome = 0;

    let totalExpenses = 0;

    let latestBalance = 0;


    for (
        let i = 1;
        i < lines.length;
        i++
    ) {

        const columns =
            parseCSVLine(
                lines[i]
            );


        const date =
            columns[
                dateIndex >= 0
                    ? dateIndex
                    : 0
            ] || "";


        const description =
            columns[
                descriptionIndex >= 0
                    ? descriptionIndex
                    : 1
            ] || "Bank transaction";


        if (!date) {

            continue;

        }


        let amount = 0;

        let type = "expense";


        if (
            amountIndex >= 0
        ) {

            const rawText =
                columns[
                    amountIndex
                ] || "";


            const raw =
                moneyToNumber(
                    rawText
                );


            amount =
                Math.abs(
                    raw
                );


            type =
                raw < 0
                    ? "expense"
                    : (
                        detectCSVIncome(
                            description,
                            rawText
                        )
                            ? "income"
                            : "income"
                    );

        } else {

            const credit =
                creditIndex >= 0
                    ? moneyToNumber(
                        columns[
                            creditIndex
                        ]
                    )
                    : 0;


            const debit =
                debitIndex >= 0
                    ? moneyToNumber(
                        columns[
                            debitIndex
                        ]
                    )
                    : 0;


            if (
                Math.abs(credit) > 0
            ) {

                amount =
                    Math.abs(
                        credit
                    );

                type =
                    "income";

            } else {

                amount =
                    Math.abs(
                        debit
                    );

                type =
                    "expense";

            }

        }


        if (
            amount <= 0
        ) {

            continue;

        }


        if (
            balanceIndex >= 0 &&
            columns[balanceIndex]
        ) {

            latestBalance =
                moneyToNumber(
                    columns[
                        balanceIndex
                    ]
                );

        }


        const cleanDescription =
            description.trim();


        const category =
            determineCategory(
                cleanDescription
            );


        const transaction = {

            date:
                normalizeDateString(
                    date
                ),

            description:
                cleanDescription,

            amount:
                roundMoney(
                    amount
                ),

            type,

            category,

            balance:
                roundMoney(
                    latestBalance
                )

        };


        transactions.push(
            transaction
        );


        if (
            type === "income"
        ) {

            totalIncome +=
                amount;

        } else {

            totalExpenses +=
                amount;

        }

    }


    return {

        transactions,

        totalIncome:
            roundMoney(
                totalIncome
            ),

        totalExpenses:
            roundMoney(
                totalExpenses
            ),

        balance:
            roundMoney(
                latestBalance
            ),

        categories:
            calculateCategories(
                transactions
            )

    };

}


// ============================================================
// CSV HELPERS
// ============================================================

function detectCSVIncome(
    description,
    rawText
) {

    const upper =
        String(
            description || ""
        ).toUpperCase();


    const raw =
        String(
            rawText || ""
        ).toUpperCase();


    return (
        isIncomeDescription(upper) ||
        raw.includes("CR") ||
        raw.includes("CREDIT")
    );

}


function normalizeHeader(value) {

    return String(
        value || ""
    )
        .toLowerCase()
        .replace(
            /^\uFEFF/,
            ""
        )
        .replace(
            /\s+/g,
            " "
        )
        .trim();

}


function findColumn(
    headers,
    names
) {

    for (
        const name
        of names
    ) {

        const index =
            headers.indexOf(
                name
            );


        if (
            index !== -1
        ) {

            return index;

        }

    }


    for (
        const name
        of names
    ) {

        const index =
            headers.findIndex(
                header =>
                    header.includes(
                        name
                    )
            );


        if (
            index !== -1
        ) {

            return index;

        }

    }


    return -1;

}


function parseCSVLine(line) {

    const result = [];

    let current = "";

    let insideQuotes = false;


    for (
        let i = 0;
        i < line.length;
        i++
    ) {

        const character =
            line[i];


        if (
            character === '"' &&
            line[i + 1] === '"'
        ) {

            current += '"';

            i++;

            continue;

        }


        if (
            character === '"'
        ) {

            insideQuotes =
                !insideQuotes;

            continue;

        }


        if (
            character === "," &&
            !insideQuotes
        ) {

            result.push(
                current.trim()
            );

            current = "";

        } else {

            current +=
                character;

        }

    }


    result.push(
        current.trim()
    );


    return result;

}


// ============================================================
// FINANCIAL HELPERS
// ============================================================

function emptyFinancialResult() {

    return {

        transactions: [],

        totalIncome: 0,

        totalExpenses: 0,

        balance: 0,

        categories: {}

    };

}


function moneyToNumber(value) {

    if (
        value === null ||
        value === undefined ||
        value === ""
    ) {

        return 0;

    }


    let cleaned =
        String(value)
            .trim()
            .replace(
                /R/gi,
                ""
            )
            .replace(
                /\s/g,
                ""
            )
            .replace(
                /,/g,
                ""
            );


    if (
        /^\(.*\)$/.test(
            cleaned
        )
    ) {

        cleaned =
            "-" +
            cleaned
                .replace(
                    /^\(/,
                    ""
                )
                .replace(
                    /\)$/,
                    ""
                );

    }


    cleaned =
        cleaned
            .replace(
                /CR$/i,
                ""
            )
            .replace(
                /DR$/i,
                ""
            );


    const number =
        parseFloat(
            cleaned
        );


    return Number.isFinite(
        number
    )
        ? number
        : 0;

}


function roundMoney(value) {

    const number =
        Number(value);


    if (
        !Number.isFinite(
            number
        )
    ) {

        return 0;

    }


    return Math.round(
        (
            number +
            Number.EPSILON
        ) * 100
    ) / 100;

}


// ============================================================
// INCOME DETECTION
// ============================================================

function isIncomeDescription(text) {

    const upper =
        String(
            text || ""
        ).toUpperCase();


    return (

        upper.includes("SALARY") ||

        upper.includes("WAGE") ||

        upper.includes("PAYROLL") ||

        upper.includes("EFT CREDIT") ||

        upper.includes("CREDIT") ||

        upper.includes("DEPOSIT") ||

        upper.includes("INTEREST") ||

        upper.includes("REFUND") ||

        upper.includes("CASH DEPOSIT") ||

        upper.includes("INCOME") ||

        upper.includes("PENSION") ||

        upper.includes("ALLOWANCE") ||

        upper.includes("TRANSFER IN") ||

        upper.includes("RECEIVED")

    );

}


// ============================================================
// CATEGORIES
// ============================================================

function determineCategory(
    description
) {

    const text =
        String(
            description || ""
        )
            .toUpperCase();


    if (
        isIncomeDescription(text)
    ) {

        return "Income";

    }


    if (
        text.includes("GROCERY") ||
        text.includes("SHOPRITE") ||
        text.includes("CHECKERS") ||
        text.includes("PICK N PAY") ||
        text.includes("PICKNPAY") ||
        text.includes("WOOLWORTHS") ||
        text.includes("SPAR") ||
        text.includes("FOOD")
    ) {

        return "Groceries";

    }


    if (
        text.includes("RESTAURANT") ||
        text.includes("TAKEAWAY") ||
        text.includes("KFC") ||
        text.includes("MCDONALD") ||
        text.includes("NANDO") ||
        text.includes("DEBONAIRS") ||
        text.includes("STEERS") ||
        text.includes("PIZZA")
    ) {

        return "Food";

    }


    if (
        text.includes("FUEL") ||
        text.includes("PETROL") ||
        text.includes("GARAGE") ||
        text.includes("ENGEN") ||
        text.includes("SHELL") ||
        text.includes("BP ") ||
        text.includes("TOTALENERGIES") ||
        text.includes("UBER") ||
        text.includes("BOLT") ||
        text.includes("TAXI")
    ) {

        return "Transport";

    }


    if (
        text.includes("VODACOM") ||
        text.includes("MTN") ||
        text.includes("TELKOM") ||
        text.includes("CELL C") ||
        text.includes("CELLC")
    ) {

        return "Mobile";

    }


    if (
        text.includes("INTERNET") ||
        text.includes("DATA")
    ) {

        return "Internet";

    }


    if (
        text.includes("ELECTRICITY") ||
        text.includes("ESKOM") ||
        text.includes("POWER")
    ) {

        return "Electricity";

    }


    if (
        text.includes("PHARMACY") ||
        text.includes("MEDICAL") ||
        text.includes("DOCTOR") ||
        text.includes("CLINIC") ||
        text.includes("HOSPITAL")
    ) {

        return "Healthcare";

    }


    if (
        text.includes("GAME") ||
        text.includes("MR PRICE") ||
        text.includes("TAKEALOT") ||
        text.includes("RETAIL") ||
        text.includes("EDGARS") ||
        text.includes("ACKERMANS")
    ) {

        return "Shopping";

    }


    if (
        text.includes("ATM") ||
        text.includes("CASH WITHDRAWAL") ||
        text.includes("CASH WD")
    ) {

        return "Cash Withdrawal";

    }


    if (
        text.includes("FEE") ||
        text.includes("CHARGE") ||
        text.includes("BANK FEE")
    ) {

        return "Bank Fees";

    }


    if (
        text.includes("RENT") ||
        text.includes("ACCOMMODATION") ||
        text.includes("PROPERTY")
    ) {

        return "Housing";

    }


    if (
        text.includes("DSTV") ||
        text.includes("NETFLIX") ||
        text.includes("SPOTIFY") ||
        text.includes("SHOWMAX") ||
        text.includes("YOUTUBE")
    ) {

        return "Entertainment";

    }


    return "Other";

}


function calculateCategories(
    transactions
) {

    const categories = {};


    for (
        const transaction
        of transactions || []
    ) {

        if (
            transaction.type !==
            "expense"
        ) {

            continue;

        }


        const category =
            transaction.category ||
            "Other";


        categories[category] =
            (
                categories[category] ||
                0
            ) +
            Number(
                transaction.amount || 0
            );

    }


    for (
        const category
        in categories
    ) {

        categories[category] =
            roundMoney(
                categories[category]
            );

    }


    return categories;

}


// ============================================================
// REMOVE DUPLICATES
// ============================================================

function removeDuplicateTransactions(
    transactions
) {

    const seen =
        new Set();

    const result = [];


    for (
        const transaction
        of transactions || []
    ) {

        if (!transaction) {

            continue;

        }


        const key =
            [
                transaction.date || "",

                String(
                    transaction.description || ""
                )
                    .trim()
                    .toLowerCase(),

                roundMoney(
                    transaction.amount || 0
                ),

                transaction.type || "",

                roundMoney(
                    transaction.balance || 0
                )

            ].join("|");


        if (
            seen.has(key)
        ) {

            continue;

        }


        seen.add(key);

        result.push(
            transaction
        );

    }


    return result;

}


// ============================================================
// DASHBOARD UPDATE
// ============================================================

function updateFinancialDashboard(
    result
) {

    if (!result) {

        return;

    }


    const income =
        getElement("income");


    const expenses =
        getElement("expenses");


    const balance =
        getElement("balance");


    if (income) {

        income.textContent =
            formatCurrency(
                result.totalIncome
            );

    }


    if (expenses) {

        expenses.textContent =
            formatCurrency(
                result.totalExpenses
            );

    }


    if (balance) {

        balance.textContent =
            formatCurrency(
                result.balance
            );

    }

}


function updateDashboardFromMonthlyData(
    data
) {

    if (!data) {

        return;

    }


    updateFinancialDashboard({

        totalIncome:
            data.income,

        totalExpenses:
            data.expenses,

        balance:
            data.balance

    });

}


function formatCurrency(amount) {

    const value =
        Number(amount || 0);


    return (
        "R" +
        value.toLocaleString(
            "en-ZA",
            {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
            }
        )
    );

}


// ============================================================
// FINANCIAL FEEDBACK
// ============================================================

function generateFinancialFeedback(
    result
) {

    const analysis =
        getElement("analysis");


    if (
        !analysis ||
        !result
    ) {

        return;

    }


    const entries =
        Object.entries(
            result.categories || {}
        ).sort(
            (a, b) =>
                Number(b[1]) -
                Number(a[1])
        );


    let html = `

        <h3>📊 Financial Analysis</h3>

        <p>
            <strong>Total Income:</strong>
            ${formatCurrency(result.totalIncome)}
        </p>

        <p>
            <strong>Total Expenses:</strong>
            ${formatCurrency(result.totalExpenses)}
        </p>

        <p>
            <strong>Closing Balance:</strong>
            ${formatCurrency(result.balance)}
        </p>

        <p>
            <strong>Transactions:</strong>
            ${result.transactions.length}
        </p>

    `;


    if (
        entries.length > 0
    ) {

        html += `

            <hr>

            <h3>💡 Biggest Spending Category</h3>

            <p>
                ${escapeHTML(entries[0][0])}:
                <strong>
                    ${formatCurrency(entries[0][1])}
                </strong>
            </p>

            <hr>

            <h3>📂 Spending Categories</h3>

            <ul>

        `;


        for (
            const [
                category,
                amount
            ]
            of entries
        ) {

            html += `

                <li>
                    ${escapeHTML(category)}:
                    <strong>
                        ${formatCurrency(amount)}
                    </strong>
                </li>

            `;

        }


        html += `
            </ul>
        `;

    }


    const available =
        roundMoney(
            Number(
                result.totalIncome || 0
            ) -
            Number(
                result.totalExpenses || 0
            )
        );


    html += `<hr>`;


    if (
        available > 0
    ) {

        html += `

            <p>
                ✅ Your recorded income is higher
                than your recorded expenses by
                <strong>
                    ${formatCurrency(available)}
                </strong>.
            </p>

        `;

    } else {

        html += `

            <p>
                ⚠️ Your recorded expenses are equal
                to or higher than your recorded income.
            </p>

        `;

    }


    analysis.innerHTML =
        html;

}


// ============================================================
// AI DASHBOARD FEATURES
// ============================================================
//
// This section powers all of the "beyond the chatbot" AI
// features: dashboard insights, health score, forecast,
// anomaly detection, the AI categorizer, and the goal
// planner. Every feature calls the Node/Gemini backend.
// ============================================================

async function postJSON(url, body) {

    const response = await fetch(url, {

        method: "POST",

        headers: {
            "Content-Type": "application/json",
            "Accept": "application/json"
        },

        body: JSON.stringify(body || {})

    });

    const text = await response.text();

    let data = {};

    try {
        data = text ? JSON.parse(text) : {};
    } catch (parseError) {
        throw new Error("The AI server returned an invalid response.");
    }

    if (!response.ok) {
        throw new Error(data?.error || `Request failed (${response.status}).`);
    }

    return data;

}


// ------------------------------------------------------------
// BUILD A COMPACT FINANCIAL DATA PAYLOAD
// ------------------------------------------------------------
// Mirrors the payload used by the chatbot, kept small to
// avoid HTTP 413 errors.
// ------------------------------------------------------------

function buildCompactFinancialData(result) {

    const transactions =
        Array.isArray(allFinancialTransactions)
            ? allFinancialTransactions
            : [];

    const compactTransactions =
        transactions
            .slice(-40)
            .map(transaction => ({

                date: String(transaction?.date || "").slice(0, 30),

                description: String(
                    transaction?.description ||
                    transaction?.name ||
                    ""
                ).slice(0, 100),

                amount: Number(transaction?.amount || 0),

                type: transaction?.type || "expense",

                category: String(transaction?.category || "").slice(0, 50)

            }));

    return {

        totalIncome: Number(result?.totalIncome || 0),

        totalExpenses: Number(result?.totalExpenses || 0),

        balance: Number(result?.balance || 0),

        transactions: transactions.length,

        transactionSample: compactTransactions

    };

}


// ------------------------------------------------------------
// RUN ALL AUTOMATIC AI FEATURES
// ------------------------------------------------------------
// Called right after a statement is analysed (or financial
// history is loaded) so the dashboard fills in with AI
// content without the user needing to ask for it.
// ------------------------------------------------------------

function runAutomaticAIFeatures(result) {

    if (!result) {
        return;
    }

    const financialData = buildCompactFinancialData(result);

    loadAIInsights(financialData);

    loadAIHealthScore(financialData);

    loadAIForecast(financialData);

    loadAIAnomalies();

}


// ------------------------------------------------------------
// AI INSIGHTS
// ------------------------------------------------------------

async function loadAIInsights(financialData) {

    const container = getElement("aiInsights");

    if (!container) {
        return;
    }

    container.innerHTML =
        `<p class="ai-loading">🤖 Generating AI insights...</p>`;

    try {

        const data =
            await postJSON(AI_INSIGHTS_URL, { financialData });

        const insights =
            Array.isArray(data?.insights) ? data.insights : [];

        if (insights.length === 0) {

            container.innerHTML =
                `<p class="ai-placeholder">No insights available yet.</p>`;

            return;

        }

        container.innerHTML =
            `<ul class="insight-list">` +
            insights
                .map(insight => `<li>💡 ${escapeHTML(insight)}</li>`)
                .join("") +
            `</ul>`;

    } catch (error) {

        console.error("AI INSIGHTS ERROR:", error);

        container.innerHTML =
            `<p class="ai-placeholder">⚠️ Could not load AI insights right now.</p>`;

    }

}


// ------------------------------------------------------------
// AI HEALTH SCORE
// ------------------------------------------------------------

function healthScoreClass(score) {

    if (score < 40) return "score-poor";
    if (score < 70) return "score-fair";
    return "score-good";

}


async function loadAIHealthScore(financialData) {

    const container = getElement("aiHealthScore");

    if (!container) {
        return;
    }

    container.innerHTML =
        `<p class="ai-loading">🤖 Calculating your health score...</p>`;

    try {

        const data =
            await postJSON(AI_HEALTH_SCORE_URL, { financialData });

        const score =
            Number.isFinite(Number(data?.score)) ? Number(data.score) : 0;

        const factors =
            Array.isArray(data?.factors) ? data.factors : [];

        container.innerHTML = `

            <div class="health-score-wrap">

                <div class="health-score-number ${healthScoreClass(score)}">
                    ${score}
                </div>

                <div>
                    <span class="health-score-label">
                        ${escapeHTML(data?.label || "")}
                    </span>
                    <span>
                        ${escapeHTML(data?.explanation || "")}
                    </span>
                </div>

            </div>

            ${
                factors.length > 0
                    ? `<ul class="health-score-factors">` +
                      factors.map(f => `<li>${escapeHTML(f)}</li>`).join("") +
                      `</ul>`
                    : ""
            }

        `;

    } catch (error) {

        console.error("AI HEALTH SCORE ERROR:", error);

        container.innerHTML =
            `<p class="ai-placeholder">⚠️ Could not calculate a health score right now.</p>`;

    }

}


// ------------------------------------------------------------
// AI SPENDING FORECAST
// ------------------------------------------------------------

async function loadAIForecast(financialData) {

    const container = getElement("aiForecast");

    if (!container) {
        return;
    }

    container.innerHTML =
        `<p class="ai-loading">🤖 Forecasting next month...</p>`;

    try {

        const currentMonth = getMonthlyFinancialData(0);
        const previousMonth = getMonthlyFinancialData(-1);

        const data =
            await postJSON(AI_FORECAST_URL, {
                financialData,
                currentMonth,
                previousMonth
            });

        const trend =
            ["improving", "stable", "worsening"].includes(data?.trend)
                ? data.trend
                : "stable";

        container.innerHTML = `

            <span class="trend-badge trend-${trend}">
                ${trend.toUpperCase()}
            </span>

            <div class="forecast-grid">

                <div class="forecast-stat">
                    <span>Predicted Income</span>
                    <strong>${formatCurrency(data?.predictedIncome)}</strong>
                </div>

                <div class="forecast-stat">
                    <span>Predicted Expenses</span>
                    <strong>${formatCurrency(data?.predictedExpenses)}</strong>
                </div>

                <div class="forecast-stat">
                    <span>Predicted Balance</span>
                    <strong>${formatCurrency(data?.predictedBalance)}</strong>
                </div>

            </div>

            <p>${escapeHTML(data?.explanation || "")}</p>

        `;

    } catch (error) {

        console.error("AI FORECAST ERROR:", error);

        container.innerHTML =
            `<p class="ai-placeholder">⚠️ Could not generate a forecast right now.</p>`;

    }

}


// ------------------------------------------------------------
// AI ANOMALY DETECTION
// ------------------------------------------------------------

async function loadAIAnomalies() {

    const container = getElement("aiAnomalies");

    if (!container) {
        return;
    }

    container.innerHTML =
        `<p class="ai-loading">🤖 Scanning for unusual transactions...</p>`;

    try {

        const transactions =
            Array.isArray(allFinancialTransactions)
                ? allFinancialTransactions.slice(-60)
                : [];

        const data =
            await postJSON(AI_ANOMALIES_URL, { transactions });

        const anomalies =
            Array.isArray(data?.anomalies) ? data.anomalies : [];

        if (anomalies.length === 0) {

            container.innerHTML =
                `<p class="ai-placeholder">✅ No unusual transactions detected.</p>`;

            return;

        }

        container.innerHTML =
            `<ul class="anomaly-list">` +
            anomalies
                .map(a => `
                    <li>
                        <strong>${escapeHTML(a.description || "Unknown")}</strong>
                        <span class="anomaly-amount">
                            ${formatCurrency(a.amount)}
                        </span>
                        <br>
                        <small>${escapeHTML(a.date || "")}</small>
                        <br>
                        ${escapeHTML(a.reason || "")}
                    </li>
                `)
                .join("") +
            `</ul>`;

    } catch (error) {

        console.error("AI ANOMALIES ERROR:", error);

        container.innerHTML =
            `<p class="ai-placeholder">⚠️ Could not run anomaly detection right now.</p>`;

    }

}


// ------------------------------------------------------------
// AI TRANSACTION CATEGORIZER
// ------------------------------------------------------------

const categorizeButton = getElement("categorizeButton");

if (categorizeButton) {

    categorizeButton.addEventListener("click", runAICategorizer);

}


async function runAICategorizer() {

    const status = getElement("categorizeStatus");
    const results = getElement("categorizeResults");

    const uncategorized =
        (Array.isArray(allFinancialTransactions) ? allFinancialTransactions : [])
            .filter(t => (t.category || "Other") === "Other");

    if (uncategorized.length === 0) {

        setStatus(status, "✅ No 'Other' transactions found — nothing to re-categorize.");

        if (results) results.innerHTML = "";

        return;

    }

    if (categorizeButton) categorizeButton.disabled = true;

    setStatus(status, `⏳ Asking AI to categorize ${uncategorized.length} transaction(s)...`);

    try {

        const payload =
            uncategorized.slice(0, 60).map(t => ({
                description: t.description || "",
                amount: t.amount || 0
            }));

        const data =
            await postJSON(AI_CATEGORIZE_URL, { transactions: payload });

        const categorized =
            Array.isArray(data?.categorized) ? data.categorized : [];

        let updatedCount = 0;

        categorized.forEach(entry => {

            const match =
                allFinancialTransactions.find(
                    t =>
                        (t.description || "") === entry.description &&
                        (t.category || "Other") === "Other"
                );

            if (match && entry.category && entry.category !== "Other") {
                match.category = entry.category;
                updatedCount++;
            }

        });

        setStatus(
            status,
            `✅ AI re-categorized ${updatedCount} of ${uncategorized.length} transaction(s).`
        );

        if (results) {

            results.innerHTML =
                updatedCount > 0
                    ? `<ul class="category-fix-list">` +
                      categorized
                          .filter(c => c.category !== "Other")
                          .map(c => `<li>${escapeHTML(c.description)} → <strong>${escapeHTML(c.category)}</strong></li>`)
                          .join("") +
                      `</ul>`
                    : "";

        }

        // Refresh the dashboard so updated categories show up.
        if (lastFinancialResult) {

            lastFinancialResult.categories =
                calculateCategories(allFinancialTransactions);

            generateFinancialFeedback(lastFinancialResult);

        }

    } catch (error) {

        console.error("AI CATEGORIZE ERROR:", error);

        setStatus(status, "❌ Could not categorize transactions right now.");

    } finally {

        if (categorizeButton) categorizeButton.disabled = false;

    }

}


// ------------------------------------------------------------
// AI SMART GOAL PLANNER
// ------------------------------------------------------------

const goalPlanButton = getElement("goalPlanButton");

if (goalPlanButton) {

    goalPlanButton.addEventListener("click", runAIGoalPlanner);

}

const goalInputField = getElement("goalInput");

if (goalInputField) {

    goalInputField.addEventListener("keypress", event => {

        if (event.key === "Enter") {
            runAIGoalPlanner();
        }

    });

}


async function runAIGoalPlanner() {

    const status = getElement("goalPlanStatus");
    const results = getElement("goalPlanResults");
    const input = getElement("goalInput");

    const goal = String(input?.value || "").trim();

    if (!goal) {

        setStatus(status, "❌ Please describe a financial goal first.");

        return;

    }

    if (goalPlanButton) goalPlanButton.disabled = true;

    setStatus(status, "⏳ Building your AI-powered plan...");

    if (results) results.innerHTML = "";

    try {

        const financialData =
            lastFinancialResult
                ? buildCompactFinancialData(lastFinancialResult)
                : null;

        const data =
            await postJSON(AI_GOAL_PLAN_URL, { goal, financialData });

        setStatus(status, "✅ Plan ready.");

        const steps =
            Array.isArray(data?.steps) ? data.steps : [];

        if (results) {

            results.innerHTML = `

                <div class="goal-plan-box">

                    ${
                        data?.monthlyTarget > 0
                            ? `<p><strong>Suggested monthly target:</strong> ${formatCurrency(data.monthlyTarget)}</p>`
                            : ""
                    }

                    ${
                        data?.timeframeMonths > 0
                            ? `<p><strong>Estimated timeframe:</strong> ${escapeHTML(String(data.timeframeMonths))} month(s)</p>`
                            : ""
                    }

                    <p>${escapeHTML(data?.explanation || "")}</p>

                    ${
                        steps.length > 0
                            ? `<ul>` +
                              steps.map(s => `<li>${escapeHTML(s)}</li>`).join("") +
                              `</ul>`
                            : ""
                    }

                </div>

            `;

        }

    } catch (error) {

        console.error("AI GOAL PLAN ERROR:", error);

        setStatus(status, "❌ Could not build a plan right now.");

    } finally {

        if (goalPlanButton) goalPlanButton.disabled = false;

    }

}


// ============================================================
// CHATBOT ELEMENTS
// ============================================================

const chatbot =
    getElement("chatbot");

const chatbotToggle =
    getElement("chatbotToggle");

const closeChat =
    getElement("closeChat");

const chatInput =
    getElement("chatInput");

const sendMessageButton =
    getElement("sendMessage");

const chatMessages =
    getElement("chatMessages");

const chatUploadButton =
    getElement("chatUploadButton");

const chatStatementFile =
    getElement("chatStatementFile");

// ============================================================
// INITIALISE VOICE CONTROLS
// ============================================================

createVoiceControls();
// ============================================================
// OPEN CHAT
// ============================================================

if (chatbotToggle) {

    chatbotToggle.addEventListener(
        "click",
        () => {

            if (!chatbot) {

                return;

            }


            chatbot.classList.toggle(
                "hidden"
            );


            if (
                !chatbot.classList.contains(
                    "hidden"
                )
            ) {

                setTimeout(
                    () => {

                        chatInput?.focus();

                    },
                    100
                );

            }

        }
    );

}


// ============================================================
// CLOSE CHAT
// ============================================================

if (closeChat) {

    closeChat.addEventListener(
        "click",
        () => {

            chatbot?.classList.add(
                "hidden"
            );

        }
    );

}


// ============================================================
// SEND BUTTON
// ============================================================

if (sendMessageButton) {

    sendMessageButton.addEventListener(
        "click",
        sendMessage
    );

}


// ============================================================
// ENTER KEY
// ============================================================

if (chatInput) {

    chatInput.addEventListener(
        "keydown",
        event => {

            if (
                event.key === "Enter"
            ) {

                event.preventDefault();

                sendMessage();

            }

        }
    );

}


// ============================================================
// QUICK QUESTIONS
// ============================================================

document
    .querySelectorAll(
        ".quick-questions button"
    )
    .forEach(
        button => {

            button.addEventListener(
                "click",
                () => {

                    const question =
                        button.dataset.question ||
                        button.textContent.trim();


                    if (!chatInput) {

                        return;

                    }


                    chatInput.value =
                        question;


                    sendMessage();

                }
            );

        }
    );


// ============================================================
// CHAT UPLOAD BUTTON
// ============================================================

if (
    chatUploadButton &&
    chatStatementFile
) {

    chatUploadButton.addEventListener(
        "click",
        () => {

            chatStatementFile.click();

        }
    );


    chatStatementFile.addEventListener(
        "change",
        handleChatStatementUpload
    );

}


// ============================================================
// CHAT STATEMENT UPLOAD
// ============================================================

async function handleChatStatementUpload() {

    const file =
        chatStatementFile?.files?.[0];


    if (!file) {

        return;

    }


    if (
        !isValidStatementFile(file)
    ) {

        addMessage(
            "❌ Please upload a valid PDF or CSV bank statement.",
            "bot"
        );


        chatStatementFile.value = "";

        return;

    }


    addMessage(
        `📎 ${escapeHTML(file.name)} selected.`,
        "user"
    );


    const thinking =
        addMessage(
            "🔎 Analysing your statement...",
            "bot",
            true
        );


    try {

        const result =
            await processChatStatement(
                file
            );


        if (
            !result ||
            !result.transactions ||
            result.transactions.length === 0
        ) {

            throw new Error(
                "No transactions were detected in this statement."
            );

        }


        lastFinancialResult =
            result;


        allFinancialTransactions =
            removeDuplicateTransactions(
                [
                    ...allFinancialTransactions,
                    ...result.transactions
                ]
            );


        updateFinancialDashboard(
            result
        );


        generateFinancialFeedback(
            result
        );


        runAutomaticAIFeatures(
            result
        );


        thinking?.remove();


        addMessage(
            buildStatementResponse(
                result
            ),
            "bot"
        );


        try {

            await saveChatStatement(
                file,
                result
            );


            addMessage(
                "☁️ Your statement was also saved to your account.",
                "bot"
            );

        } catch (firebaseError) {

            console.error(
                "CHAT FIREBASE SAVE ERROR:",
                firebaseError
            );


            addMessage(
                "⚠️ Statement analysed successfully, but Firebase could not save it.",
                "bot"
            );

        }

    } catch (error) {

        console.error(
            "CHAT STATEMENT ERROR:",
            error
        );


        thinking?.remove();


        addMessage(
            `❌ I could not analyse that statement.<br><br>${escapeHTML(error.message || "Unknown error.")}`,
            "bot"
        );

    }


    chatStatementFile.value = "";

}


// ============================================================
// PROCESS CHAT STATEMENT
// ============================================================

async function processChatStatement(
    file
) {

    if (
        !isValidStatementFile(file)
    ) {

        throw new Error(
            "Only PDF and CSV files are supported."
        );

    }


    if (
        isPDF(file)
    ) {

        return await analysePDF(
            file
        );

    }


    return await analyseCSV(
        file
    );

}


// ============================================================
// SAVE CHAT STATEMENT
// ============================================================

async function saveChatStatement(
    file,
    result
) {

    if (!currentUser) {

        throw new Error(
            "You must be logged in."
        );

    }


    if (!storage) {

        throw new Error(
            "Firebase Storage is not configured."
        );

    }


    const safeFileName =
        sanitizeFileName(
            file.name
        );


    const filePath =
        `statements/${currentUser.uid}/chat_${Date.now()}_${safeFileName}`;


    const fileRef =
        ref(
            storage,
            filePath
        );


    await uploadBytes(
        fileRef,
        file
    );


    const downloadURL =
        await getDownloadURL(
            fileRef
        );


    await addDoc(
        collection(
            db,
            "statements"
        ),
        {

            userId:
                currentUser.uid,

            fileName:
                file.name,

            source:
                "chatbot",

            filePath,

            downloadURL,

            uploadedAt:
                serverTimestamp(),

            totalIncome:
                Number(
                    result.totalIncome || 0
                ),

            totalExpenses:
                Number(
                    result.totalExpenses || 0
                ),

            balance:
                Number(
                    result.balance || 0
                ),

            categories:
                result.categories || {},

            transactions:
                result.transactions || []

        }
    );

}


// ============================================================
// STATEMENT RESPONSE
// ============================================================

function buildStatementResponse(
    result
) {

    return `

        ✅ <strong>Statement analysed successfully!</strong>

        <br><br>

        💰 Income:
        <strong>
            ${formatCurrency(result.totalIncome)}
        </strong>

        <br>

        💳 Expenses:
        <strong>
            ${formatCurrency(result.totalExpenses)}
        </strong>

        <br>

        🏦 Balance:
        <strong>
            ${formatCurrency(result.balance)}
        </strong>

        <br>

        📄 Transactions:
        <strong>
            ${result.transactions.length}
        </strong>

        <br><br>

        You can now ask me:

        <br><br>

        • How much did I spend this month?<br>
        • What is my biggest expense?<br>
        • Where am I spending the most?<br>
        • How can I save money?<br>
        • Compare this month with last month.

    `;

}


// ============================================================
// SEND CHAT MESSAGE
// ============================================================

async function sendMessage() {

    if (!chatInput) {

        return;

    }


    const text =
        chatInput.value.trim();


    if (!text) {

        return;

    }


    addMessage(
        text,
        "user"
    );


    chatInput.value = "";


    const thinking =
        addMessage(
            "Thinking...",
            "bot",
            true
        );


    if (sendMessageButton) {

        sendMessageButton.disabled =
            true;

    }


    try {

        const response =
            await generateBotResponse(
                text
            );


        thinking?.remove();


        // IMPORTANT:
        // Never display undefined.
        if (
            response === undefined ||
            response === null ||
            String(response).trim() === ""
        ) {

            addMessage(
                "🤖 I couldn't generate a response. Please try again.",
                "bot"
            );

        } else {

            addMessage(
    String(response),
    "bot"
);


// ========================================================
// AUTOMATIC VOICE RESPONSE
// ========================================================

if (lastVoiceMessage) {

    speakText(
        String(response),
        selectedLanguage
    );


    lastVoiceMessage =
        false;

}

        }

    } catch (error) {

        console.error(
            "CHAT ERROR:",
            error
        );


        thinking?.remove();


        addMessage(
            `❌ ${escapeHTML(error.message || "Something went wrong while processing your question.")}`,
            "bot"
        );

    } finally {

        if (sendMessageButton) {

            sendMessageButton.disabled =
                false;

        }


        chatInput?.focus();

    }

}


// ============================================================
// MAIN BOT
// ============================================================

async function generateBotResponse(
    question
) {

    const originalQuestion =
        String(
            question || ""
        ).trim();


    const q =
        originalQuestion.toLowerCase();


    const name =
        currentProfile?.firstName ||
        "there";


    // ========================================================
    // GREETINGS
    // ========================================================

    if (
        /^(hi|hello|hey|hiya|howdy)(\s|!|\.|,|$)/i.test(
            originalQuestion
        )
    ) {

        return `

            Hi ${escapeHTML(name)} 👋

            <br><br>

            I'm your <strong>Financial Advisor AI</strong>.

            <br><br>

            You can ask me about:

            <br><br>

            💰 Money and finance<br>
            📊 Spending and expenses<br>
            💵 Income and savings<br>
            📋 Budgeting<br>
            📄 Bank statements<br>
            💻 Programming<br>
            🎓 Education<br>
            🔬 Science<br>
            📚 General questions

            <br><br>

            What would you like to know?

        `;

    }


    // ========================================================
    // GOOD MORNING
    // ========================================================

    if (
        q.includes("good morning")
    ) {

        return `
            Good morning ${escapeHTML(name)} ☀️
            <br><br>
            How can I help you today?
        `;

    }


    // ========================================================
    // GOOD AFTERNOON
    // ========================================================

    if (
        q.includes("good afternoon")
    ) {

        return `
            Good afternoon ${escapeHTML(name)} 👋
            <br><br>
            What would you like to know?
        `;

    }


    // ========================================================
    // GOOD EVENING
    // ========================================================

    if (
        q.includes("good evening")
    ) {

        return `
            Good evening ${escapeHTML(name)} 🌙
            <br><br>
            I'm ready to help.
        `;

    }


    // ========================================================
    // THANK YOU
    // ========================================================

    if (
        q.includes("thank you") ||
        q === "thanks" ||
        q.startsWith("thanks ")
    ) {

        return `
            You're welcome, ${escapeHTML(name)} 😊
            <br><br>
            I'm happy to help.
        `;

    }


    // ========================================================
    // WHO ARE YOU
    // ========================================================

    if (
        q.includes("who are you") ||
        q.includes("what are you")
    ) {

        return `
            🤖 I'm <strong>Financial Advisor AI</strong>.

            <br><br>

            I can analyse financial information,
            help with budgeting and answer general
            questions about technology, programming,
            education, mathematics, science and more.
        `;

    }


    // ========================================================
    // HOW ARE YOU
    // ========================================================

    if (
        q.includes("how are you")
    ) {

        return `
            I'm doing great 🤖😊
            <br><br>
            Thanks for asking!
            How can I help you?
        `;

    }


    // ========================================================
    // FINANCIAL COMMANDS
    // ========================================================

    if (
        (
            q.includes("this month") ||
            q.includes("current month") ||
            q.includes("this month's")
        ) &&
        (
            q.includes("expense") ||
            q.includes("spend") ||
            q.includes("spent")
        )
    ) {

        return getCurrentMonthResponse();

    }


    if (
        (
            q.includes("previous month") ||
            q.includes("last month")
        ) &&
        (
            q.includes("expense") ||
            q.includes("spend") ||
            q.includes("spent")
        )
    ) {

        return getPreviousMonthResponse();

    }


    if (
        q.includes("compare") ||
        q.includes("comparison") ||
        q.includes("difference between")
    ) {

        return compareMonths();

    }


    if (
        (
            q.includes("biggest") ||
            q.includes("largest") ||
            q.includes("most expensive")
        ) &&
        (
            q.includes("expense") ||
            q.includes("spending") ||
            q.includes("transaction") ||
            q.includes("purchase") ||
            q.includes("category")
        )
    ) {

        if (
            q.includes("category")
        ) {

            return getTopSpendingCategories();

        }


        return getBiggestExpense();

    }


    if (
        (
            q.includes("where") ||
            q.includes("category") ||
            q.includes("categories")
        ) &&
        (
            q.includes("spend") ||
            q.includes("money") ||
            q.includes("expense")
        )
    ) {

        return getTopSpendingCategories();

    }


    if (
        q.includes("total expense") ||
        q.includes("total spending") ||
        q.includes("how much have i spent") ||
        q.includes("how much did i spend")
    ) {

        return getTotalExpensesResponse();

    }


    if (
        q.includes("income") ||
        q.includes("salary") ||
        q.includes("earn")
    ) {

        return getIncomeResponse();

    }


    if (
        q.includes("balance") ||
        q.includes("how much money do i have") ||
        q.includes("money left") ||
        q.includes("remaining")
    ) {

        return getBalanceResponse();

    }


    if (
        q.includes("save money") ||
        q.includes("saving money") ||
        q.includes("how can i save") ||
        q.includes("savings")
    ) {

        return getSavingResponse();

    }


    if (
        q.includes("budget") ||
        q.includes("budgeting")
    ) {

        return getBudgetResponse();

    }


    if (
        q.includes("reduce my expenses") ||
        q.includes("reduce expenses") ||
        q.includes("cut my expenses") ||
        q.includes("spend less")
    ) {

        return getExpenseReductionResponse();

    }


    if (
        q.includes("financial health") ||
        q.includes("am i doing well") ||
        q.includes("am i financially")
    ) {

        return getFinancialHealthResponse();

    }


    // ========================================================
    // HELP
    // ========================================================

    if (
        q === "help" ||
        q.includes("what can you do")
    ) {

        return `

            🤖 <strong>I can help with:</strong>

            <br><br>

            📊 Spending analysis<br>
            💰 Income<br>
            💳 Expenses<br>
            🏦 Balance<br>
            📅 Monthly comparisons<br>
            🛒 Spending categories<br>
            💡 Saving advice<br>
            📋 Budgeting<br>
            📄 PDF statements<br>
            📊 CSV statements<br>
            💻 Programming<br>
            🎓 Education<br>
            🔬 Science<br>
            📚 General questions

            <br><br>

            Ask me anything.

        `;

    }


    // ========================================================
    // IMPORTANT:
    // EVERYTHING ELSE GOES TO YOUR AI BACKEND.
    //
    // This is what allows:
    //
    // "What is Java?"
    // "Explain inheritance."
    // "What is inflation?"
    // "What is HTML?"
    // "Help me with mathematics."
    // "What is artificial intelligence?"
    //
    // etc.
    // ========================================================

   return await askAIBackend(
    originalQuestion,
    selectedLanguage
);
}


// ============================================================
// CURRENT MONTH
// ============================================================

function getCurrentMonthResponse() {

    const data =
        getMonthlyFinancialData(0);


    if (
        data.transactions === 0
    ) {

        return `

            📅 <strong>This Month</strong>

            <br><br>

            I don't currently have transactions
            dated in the current calendar month.

            <br><br>

            I have
            <strong>
                ${allFinancialTransactions.length}
            </strong>
            total transactions loaded.

        `;

    }


    return `

        📅 <strong>This Month</strong>

        <br><br>

        💰 Income:
        <strong>
            ${formatCurrency(data.income)}
        </strong>

        <br>

        💳 Expenses:
        <strong>
            ${formatCurrency(data.expenses)}
        </strong>

        <br>

        🏦 Net:
        <strong>
            ${formatCurrency(data.balance)}
        </strong>

        <br><br>

        Recorded transactions:
        <strong>
            ${data.transactions}
        </strong>

    `;

}


// ============================================================
// PREVIOUS MONTH
// ============================================================

function getPreviousMonthResponse() {

    const data =
        getMonthlyFinancialData(-1);


    if (
        data.transactions === 0
    ) {

        return `

            📅 <strong>Previous Month</strong>

            <br><br>

            I don't currently have transactions
            for the previous calendar month.

        `;

    }


    return `

        📅 <strong>Previous Month</strong>

        <br><br>

        💰 Income:
        <strong>
            ${formatCurrency(data.income)}
        </strong>

        <br>

        💳 Expenses:
        <strong>
            ${formatCurrency(data.expenses)}
        </strong>

        <br>

        🏦 Net:
        <strong>
            ${formatCurrency(data.balance)}
        </strong>

        <br><br>

        Transactions:
        <strong>
            ${data.transactions}
        </strong>

    `;

}


// ============================================================
// MONTHLY DATA
// ============================================================

function getMonthlyFinancialData(
    monthOffset
) {

    const now =
        new Date();


    const target =
        new Date(
            now.getFullYear(),
            now.getMonth() + monthOffset,
            1
        );


    const year =
        target.getFullYear();


    const month =
        target.getMonth();


    let income = 0;

    let expenses = 0;

    let transactionCount = 0;


    for (
        const transaction
        of allFinancialTransactions
    ) {

        const date =
            parseFinancialDate(
                transaction.date
            );


        if (!date) {

            continue;

        }


        if (
            date.getFullYear() !== year ||
            date.getMonth() !== month
        ) {

            continue;

        }


        transactionCount++;


        if (
            transaction.type === "income"
        ) {

            income +=
                Number(
                    transaction.amount || 0
                );

        } else {

            expenses +=
                Number(
                    transaction.amount || 0
                );

        }

    }


    return {

        year,

        month,

        income:
            roundMoney(income),

        expenses:
            roundMoney(expenses),

        balance:
            roundMoney(
                income - expenses
            ),

        transactions:
            transactionCount

    };

}


// ============================================================
// FINANCIAL DATE PARSER
// ============================================================

function parseFinancialDate(
    value
) {

    if (!value) {

        return null;

    }


    const text =
        String(value)
            .trim();


    let match;


    match =
        text.match(
            /^(\d{4})-(\d{2})-(\d{2})/
        );


    if (match) {

        return new Date(
            Number(match[1]),
            Number(match[2]) - 1,
            Number(match[3])
        );

    }


    match =
        text.match(
            /^(\d{2})\/(\d{2})\/(\d{4})/
        );


    if (match) {

        return new Date(
            Number(match[3]),
            Number(match[2]) - 1,
            Number(match[1])
        );

    }


    match =
        text.match(
            /^(\d{2})-(\d{2})-(\d{4})/
        );


    if (match) {

        return new Date(
            Number(match[3]),
            Number(match[2]) - 1,
            Number(match[1])
        );

    }


    match =
        text.match(
            /^(\d{2})\/(\d{2})\/(\d{2})/
        );


    if (match) {

        let year =
            Number(match[3]);


        year =
            year < 70
                ? 2000 + year
                : 1900 + year;


        return new Date(
            year,
            Number(match[2]) - 1,
            Number(match[1])
        );

    }


    match =
        text.match(
            /^(\d{2})-(\d{2})-(\d{2})/
        );


    if (match) {

        let year =
            Number(match[3]);


        year =
            year < 70
                ? 2000 + year
                : 1900 + year;


        return new Date(
            year,
            Number(match[2]) - 1,
            Number(match[1])
        );

    }


    match =
        text.match(
            /^(\d{1,2})\s+([A-Za-z]+)\s+(\d{4})/
        );


    if (match) {

        const months = {

            jan: 0,
            january: 0,

            feb: 1,
            february: 1,

            mar: 2,
            march: 2,

            apr: 3,
            april: 3,

            may: 4,

            jun: 5,
            june: 5,

            jul: 6,
            july: 6,

            aug: 7,
            august: 7,

            sep: 8,
            sept: 8,
            september: 8,

            oct: 9,
            october: 9,

            nov: 10,
            november: 10,

            dec: 11,
            december: 11

        };


        const month =
            months[
                match[2].toLowerCase()
            ];


        if (
            month !== undefined
        ) {

            return new Date(
                Number(match[3]),
                month,
                Number(match[1])
            );

        }

    }


    const parsed =
        new Date(text);


    return Number.isNaN(
        parsed.getTime()
    )
        ? null
        : parsed;

}


// ============================================================
// COMPARE MONTHS
// ============================================================

function compareMonths() {

    const current =
        getMonthlyFinancialData(0);


    const previous =
        getMonthlyFinancialData(-1);


    if (
        current.transactions === 0 &&
        previous.transactions === 0
    ) {

        return `

            📊 <strong>Monthly Comparison</strong>

            <br><br>

            I don't have enough monthly
            transaction data to compare yet.

            <br><br>

            Upload statements for the relevant
            months first.

        `;

    }


    if (
        previous.transactions === 0
    ) {

        return `

            📊 <strong>Monthly Comparison</strong>

            <br><br>

            Current month expenses:
            <strong>
                ${formatCurrency(current.expenses)}
            </strong>

            <br><br>

            I don't have previous-month
            transactions available yet.

        `;

    }


    const difference =
        roundMoney(
            current.expenses -
            previous.expenses
        );


    const percentage =
        previous.expenses === 0
            ? 0
            : (
                difference /
                previous.expenses
            ) * 100;


    const direction =
        difference > 0
            ? "increased"
            : difference < 0
                ? "decreased"
                : "stayed the same";


    return `

        📊 <strong>Monthly Expense Comparison</strong>

        <br><br>

        Previous month:
        <strong>
            ${formatCurrency(previous.expenses)}
        </strong>

        <br>

        Current month:
        <strong>
            ${formatCurrency(current.expenses)}
        </strong>

        <br><br>

        Your expenses have
        <strong>
            ${direction}
        </strong>
        by
        <strong>
            ${formatCurrency(
                Math.abs(difference)
            )}
        </strong>

        (${Math.abs(
            percentage
        ).toFixed(1)}%).


    `;

}


// ============================================================
// BIGGEST EXPENSE
// ============================================================

function getBiggestExpense() {

    const transactions =
        allFinancialTransactions
            .filter(
                transaction =>
                    transaction.type ===
                    "expense"
            );


    if (
        transactions.length === 0
    ) {

        return `
            📊 I don't have any expense
            transactions yet.
            <br><br>
            Upload a statement first.
        `;

    }


    const biggest =
        [...transactions]
            .sort(
                (a, b) =>
                    Number(b.amount || 0) -
                    Number(a.amount || 0)
            )[0];


    return `

        💰 <strong>Biggest Expense</strong>

        <br><br>

        ${escapeHTML(
            biggest.description
        )}

        <br><br>

        Category:
        <strong>
            ${escapeHTML(
                biggest.category || "Other"
            )}
        </strong>

        <br>

        Amount:
        <strong>
            ${formatCurrency(
                biggest.amount
            )}
        </strong>

        <br>

        Date:
        ${escapeHTML(
            biggest.date
        )}

    `;

}


// ============================================================
// TOP SPENDING CATEGORIES
// ============================================================

function getTopSpendingCategories() {

    const categories =
        getTopExpenseCategories();


    if (
        categories.length === 0
    ) {

        return `
            📊 I don't have spending data yet.
            <br><br>
            Upload your bank statement first.
        `;

    }


    let html = `

        📊 <strong>Your Top Spending Categories</strong>

        <br><br>

    `;


    categories
        .slice(0, 5)
        .forEach(
            (
                [
                    category,
                    amount
                ],
                index
            ) => {

                html += `

                    ${index + 1}.
                    ${escapeHTML(category)}:
                    <strong>
                        ${formatCurrency(amount)}
                    </strong>

                    <br>

                `;

            }
        );


    return html;

}


function getTopExpenseCategories() {

    const categories = {};


    for (
        const transaction
        of allFinancialTransactions
    ) {

        if (
            transaction.type !==
            "expense"
        ) {

            continue;

        }


        const category =
            transaction.category ||
            "Other";


        categories[category] =
            (
                categories[category] ||
                0
            ) +
            Number(
                transaction.amount || 0
            );

    }


    return Object.entries(
        categories
    )
        .sort(
            (a, b) =>
                Number(b[1]) -
                Number(a[1])
        );

}


// ============================================================
// TOTAL EXPENSES
// ============================================================

function getTotalExpensesResponse() {

    const total =
        allFinancialTransactions
            .filter(
                transaction =>
                    transaction.type ===
                    "expense"
            )
            .reduce(
                (
                    sum,
                    transaction
                ) =>
                    sum +
                    Number(
                        transaction.amount || 0
                    ),
                0
            );


    if (
        total === 0
    ) {

        return `

            💳 I don't have any recorded
            expenses yet.

            <br><br>

            Upload a bank statement first.

        `;

    }


    return `

        💳 <strong>Total Recorded Expenses</strong>

        <br><br>

        Your uploaded transactions contain

        <strong>
            ${formatCurrency(total)}
        </strong>

        in recorded expenses.

    `;

}


// ============================================================
// INCOME RESPONSE
// ============================================================

function getIncomeResponse() {

    const income =
        allFinancialTransactions
            .filter(
                transaction =>
                    transaction.type ===
                    "income"
            )
            .reduce(
                (
                    sum,
                    transaction
                ) =>
                    sum +
                    Number(
                        transaction.amount || 0
                    ),
                0
            );


    if (
        income === 0
    ) {

        return `

            💰 I don't have recorded income yet.

            <br><br>

            Upload your statement and I'll
            calculate your income.

        `;

    }


    return `

        💰 <strong>Recorded Income</strong>

        <br><br>

        Your uploaded statements contain

        <strong>
            ${formatCurrency(income)}
        </strong>

        in recorded income.

    `;

}


// ============================================================
// BALANCE RESPONSE
// ============================================================

function getBalanceResponse() {

    if (
        !lastFinancialResult
    ) {

        return `

            🏦 Upload a statement first so I
            can calculate your balance.

        `;

    }


    return `

        🏦 <strong>Latest Recorded Balance</strong>

        <br><br>

        Your latest statement balance is:

        <strong>
            ${formatCurrency(
                lastFinancialResult.balance
            )}
        </strong>

    `;

}


// ============================================================
// SAVING RESPONSE
// ============================================================

function getSavingResponse() {

    const current =
        getMonthlyFinancialData(0);


    if (
        current.income === 0 &&
        current.expenses === 0
    ) {

        return `

            💡 <strong>Saving Tips</strong>

            <br><br>

            1. Track every expense.<br>
            2. Separate needs from wants.<br>
            3. Reduce unnecessary spending.<br>
            4. Set a monthly savings target.<br>
            5. Build an emergency fund.

        `;

    }


    const available =
        roundMoney(
            current.income -
            current.expenses
        );


    return `

        💡 <strong>Saving Advice</strong>

        <br><br>

        Current recorded income:

        <strong>
            ${formatCurrency(
                current.income
            )}
        </strong>

        <br>

        Current recorded expenses:

        <strong>
            ${formatCurrency(
                current.expenses
            )}
        </strong>

        <br><br>

        Difference:

        <strong>
            ${formatCurrency(
                available
            )}
        </strong>

        <br><br>

        ${
            available > 0
                ? "You have a positive recorded difference. Consider saving part of it."
                : "Your expenses are consuming most or all of your recorded income. Review your largest spending categories."
        }

    `;

}


// ============================================================
// EXPENSE REDUCTION
// ============================================================

function getExpenseReductionResponse() {

    const categories =
        getTopExpenseCategories();


    if (
        categories.length === 0
    ) {

        return `

            💡 Upload your statement and I'll
            identify your biggest spending areas.

        `;

    }


    const biggest =
        categories[0];


    return `

        💡 <strong>Reducing Expenses</strong>

        <br><br>

        Your biggest spending category is:

        <strong>
            ${escapeHTML(biggest[0])}
        </strong>

        at

        <strong>
            ${formatCurrency(biggest[1])}
        </strong>.

        <br><br>

        Start by reviewing this category and
        identifying expenses that can be reduced.

    `;

}


// ============================================================
// BUDGET
// ============================================================

function getBudgetResponse() {

    const current =
        getMonthlyFinancialData(0);


    if (
        current.income === 0
    ) {

        return `

            💰 <strong>Budgeting</strong>

            <br><br>

            A simple starting budget can divide
            income between needs, wants and savings.

            <br><br>

            Upload a statement and I'll help you
            build a budget using your actual data.

        `;

    }


    const needs =
        current.income * 0.50;


    const wants =
        current.income * 0.30;


    const savings =
        current.income * 0.20;


    return `

        💰 <strong>Example Monthly Budget</strong>

        <br><br>

        Recorded income:
        <strong>
            ${formatCurrency(current.income)}
        </strong>

        <br><br>

        Needs:
        <strong>
            ${formatCurrency(needs)}
        </strong>

        <br>

        Wants:
        <strong>
            ${formatCurrency(wants)}
        </strong>

        <br>

        Savings:
        <strong>
            ${formatCurrency(savings)}
        </strong>

        <br><br>

        This is a general budgeting guideline.
        Adjust it to your actual financial situation.

    `;

}


// ============================================================
// FINANCIAL HEALTH
// ============================================================

function getFinancialHealthResponse() {

    const current =
        getMonthlyFinancialData(0);


    if (
        current.income === 0 &&
        current.expenses === 0
    ) {

        return `

            📊 Upload a statement first so I can
            assess your financial pattern.

        `;

    }


    const ratio =
        current.income > 0
            ? (
                current.expenses /
                current.income
            ) * 100
            : 100;


    let assessment;


    if (
        ratio < 50
    ) {

        assessment =
            "Your recorded expenses are relatively low compared with your recorded income.";

    } else if (
        ratio < 80
    ) {

        assessment =
            "Your spending is using a significant portion of your recorded income.";

    } else {

        assessment =
            "Your expenses are using most or all of your recorded income.";

    }


    return `

        📊 <strong>Financial Health Snapshot</strong>

        <br><br>

        Income:
        <strong>
            ${formatCurrency(current.income)}
        </strong>

        <br>

        Expenses:
        <strong>
            ${formatCurrency(current.expenses)}
        </strong>

        <br>

        Expense-to-income ratio:
        <strong>
            ${ratio.toFixed(1)}%
        </strong>

        <br><br>

        ${assessment}

    `;

}


// ============================================================
// AI BACKEND
// ============================================================
//
// THIS IS THE IMPORTANT FIX.
//
// Previously:
//     fetch("/api/chat")
//
// Now:
//     fetch("http://localhost:3000/api/chat")
//
// Your Node server is running on port 3000.
// ============================================================

async function askAIBackend(
    question,
    language = selectedLanguage
) {

    try {

        const cleanQuestion =
            String(
                question || ""
            ).trim();


        if (!cleanQuestion) {

            throw new Error(
                "Please enter a question."
            );

        }


        // ----------------------------------------------------
        // CREATE SMALL FINANCIAL DATA OBJECT
        // ----------------------------------------------------
        //
        // We intentionally send only a small amount of data.
        // This prevents HTTP 413 "Request Entity Too Large".
        //
        // ============================================================
// SAFE FINANCIAL TRANSACTION DATA
// ============================================================

const transactions =
    Array.isArray(
        allFinancialTransactions
    )
        ? allFinancialTransactions
        : [];


const compactTransactions =
    transactions
        .slice(-20)
        .map(
            transaction => ({

                date:
                    String(
                        transaction?.date || ""
                    ).slice(0, 30),

                description:
                    String(
                        transaction?.description ||
                        transaction?.name ||
                        ""
                    ).slice(0, 100),

                amount:
                    Number(
                        transaction?.amount || 0
                    ),

                type:
                    transaction?.type ||
                    "expense",

                category:
                    String(
                        transaction?.category || ""
                    ).slice(0, 50)

            })
        );


        const financialData = {

    currentMonth:
        getMonthlyFinancialData(0),

    previousMonth:
        getMonthlyFinancialData(-1),

    transactionCount:
        transactions.length,

    transactions:
        compactTransactions
};


        // ----------------------------------------------------
        // REQUEST BODY
        // ----------------------------------------------------

       const requestBody = {

    message:
        `${cleanQuestion}

LANGUAGE INSTRUCTION:
${languageInstruction(language)}`,

    financialData

};


        const requestJSON =
            JSON.stringify(
                requestBody
            );


        console.log(
            "Sending AI request:",
            {
                url: API_URL,
                size:
                    requestJSON.length,
                question:
                    cleanQuestion
            }
        );


        // ----------------------------------------------------
        // CALL NODE BACKEND
        // ----------------------------------------------------

        const response =
            await fetch(
                API_URL,
                {

                    method:
                        "POST",

                    headers: {

                        "Content-Type":
                            "application/json",

                        "Accept":
                            "application/json"

                    },

                    body:
                        requestJSON

                }
            );


        // ----------------------------------------------------
        // GET RESPONSE TEXT FIRST
        // ----------------------------------------------------

        const responseText =
            await response.text();


        console.log(
            "AI server HTTP status:",
            response.status
        );


        console.log(
            "AI server response:",
            responseText
        );


        // ----------------------------------------------------
        // CONVERT JSON
        // ----------------------------------------------------

        let data = {};


        if (
            responseText
        ) {

            try {

                data =
                    JSON.parse(
                        responseText
                    );

            } catch (jsonError) {

                console.error(
                    "INVALID JSON FROM SERVER:",
                    jsonError
                );


                throw new Error(
                    `AI server returned invalid JSON. HTTP ${response.status}.`
                );

            }

        }


        // ----------------------------------------------------
        // ERROR STATUS
        // ----------------------------------------------------

        if (
            !response.ok
        ) {

            if (
                response.status === 413
            ) {

                throw new Error(
                    "The AI request was too large (HTTP 413). The financial data has been reduced. Please restart the backend and try again."
                );

            }


            if (
                response.status === 429
            ) {

                throw new Error(
                    data?.error ||
                    "The AI API has no remaining credits."
                );

            }


            if (
                response.status === 401
            ) {

                throw new Error(
                    "The AI backend rejected the API key. Check your .env file."
                );

            }


            throw new Error(
                data?.error ||
                `AI server returned HTTP ${response.status}.`
            );

        }


        // ----------------------------------------------------
        // GET REPLY
        // ----------------------------------------------------

        let reply = null;


        if (
            typeof data?.reply === "string"
        ) {

            reply =
                data.reply;

        } else if (
            typeof data?.answer === "string"
        ) {

            reply =
                data.answer;

        } else if (
            typeof data?.message === "string"
        ) {

            reply =
                data.message;

        }


        // ----------------------------------------------------
        // MAKE SURE IT IS NOT UNDEFINED
        // ----------------------------------------------------

        if (
            !reply ||
            !reply.trim()
        ) {

            console.error(
                "SERVER DID NOT RETURN A REPLY:",
                data
            );


            throw new Error(
                "AI server returned an empty response."
            );

        }


        // ----------------------------------------------------
        // FORMAT RESPONSE
        // ----------------------------------------------------

        return escapeBotHTML(
            reply.trim()
        );

    } catch (error) {

        console.error(
            "AI BACKEND ERROR:",
            error
        );


        return `

            🤖 <strong>AI connection error</strong>

            <br><br>

            ${escapeHTML(
                error?.message ||
                "Unable to connect to the AI server."
            )}

            <br><br>

            Make sure your backend is running:

            <br><br>

            <code>node server.js</code>

        `;

    }

}


// ============================================================
// ADD CHAT MESSAGE
// ============================================================

function addMessage(
    text,
    type,
    returnElement = false
) {

    if (!chatMessages) {

        return null;

    }


    // NEVER DISPLAY "undefined"
    if (
        text === undefined ||
        text === null ||
        String(text).trim() === ""
    ) {

        text =
            type === "bot"
                ? "🤖 I couldn't generate a response."
                : "";

    }


    const message =
        document.createElement(
            "div"
        );


    message.className =
        type === "user"
            ? "user-message"
            : "bot-message";


    if (
    type === "bot"
) {

    message.innerHTML =
        String(text);


    const spokenText =
        String(text)
            .replace(
                /<[^>]*>/g,
                " "
            )
            .replace(
                /\s+/g,
                " "
            )
            .trim();


    if (spokenText) {

        const speakButton =
            document.createElement(
                "button"
            );


        speakButton.type =
            "button";


        speakButton.textContent =
            "🔊";


        speakButton.title =
            "Read this answer aloud";


        speakButton.setAttribute(
            "aria-label",
            "Read this answer aloud"
        );


        speakButton.style.cssText =
            `
            margin-left:8px;
            border:0;
            background:transparent;
            cursor:pointer;
            font-size:16px;
            `;


        speakButton.addEventListener(
            "click",
            () => {

                speakText(
                    spokenText,
                    selectedLanguage
                );

            }
        );


        message.appendChild(
            speakButton
        );

    }

} else {

        message.textContent =
            String(text);

    }


    chatMessages.appendChild(
        message
    );


    chatMessages.scrollTop =
        chatMessages.scrollHeight;


    return returnElement
        ? message
        : null;

}


// ============================================================
// FILE VALIDATION
// ============================================================

function isValidStatementFile(
    file
) {

    if (!file) {

        return false;

    }


    const name =
        String(
            file.name || ""
        )
            .toLowerCase();


    return (
        name.endsWith(".pdf") ||
        name.endsWith(".csv")
    );

}


function isPDF(file) {

    return String(
        file?.name || ""
    )
        .toLowerCase()
        .endsWith(".pdf");

}


// ============================================================
// FILE NAME
// ============================================================

function sanitizeFileName(
    name
) {

    return String(
        name || "statement"
    )
        .replace(
            /[^a-zA-Z0-9._-]/g,
            "_"
        );

}


// ============================================================
// STATUS
// ============================================================

function setStatus(
    element,
    message
) {

    if (!element) {

        return;

    }


    element.textContent =
        message;

}


// ============================================================
// HTML ESCAPE
// ============================================================

function escapeHTML(
    value
) {

    return String(
        value ?? ""
    )
        .replace(
            /&/g,
            "&amp;"
        )
        .replace(
            /</g,
            "&lt;"
        )
        .replace(
            />/g,
            "&gt;"
        )
        .replace(
            /"/g,
            "&quot;"
        )
        .replace(
            /'/g,
            "&#039;"
        );

}


// ============================================================
// AI RESPONSE FORMATTER
// ============================================================

function escapeBotHTML(
    value
) {

    const escaped =
        escapeHTML(
            value
        );


    return escaped

        // Bold
        .replace(
            /\*\*(.*?)\*\*/g,
            "<strong>$1</strong>"
        )

        // Markdown bullets
        .replace(
            /^\s*[-•]\s+/gm,
            "• "
        )

        // New lines
        .replace(
            /\r?\n/g,
            "<br>"
        );

}


// ============================================================
// END
// ============================================================