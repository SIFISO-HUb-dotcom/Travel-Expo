// ============================================================
// AUTH.JS
// Financial Advisor
// Firebase Login + Signup
// ============================================================

import { auth, db } from "./firebase.js";

import {
    createUserWithEmailAndPassword,
    signInWithEmailAndPassword,
    signOut,
    onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-auth.js";

import {
    doc,
    setDoc,
    serverTimestamp
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore.js";


console.log("AUTH.JS LOADED");


// ============================================================
// PAGE DETECTION
// ============================================================

const signupForm =
    document.getElementById("signupForm");

const loginForm =
    document.getElementById("loginForm");


// ============================================================
// MESSAGE HELPERS
// ============================================================

function showMessage(
    element,
    text,
    type = "error"
) {

    if (!element) {
        return;
    }

    element.textContent = text;

    if (type === "success") {

        element.style.color = "green";

    } else {

        element.style.color = "red";

    }
}


function setButtonLoading(
    button,
    loading,
    normalText
) {

    if (!button) {
        return;
    }

    button.disabled = loading;

    button.textContent =
        loading
            ? "Please wait..."
            : normalText;
}


// ============================================================
// FIREBASE ERROR HANDLER
// ============================================================

function getFirebaseError(error) {

    console.error(
        "Firebase error:",
        error
    );


    switch (error.code) {

        // ====================================================
        // SIGN UP
        // ====================================================

        case "auth/email-already-in-use":

            return (
                "❌ This email is already registered. " +
                "Please login instead."
            );


        case "auth/invalid-email":

            return (
                "❌ Please enter a valid email address."
            );


        case "auth/weak-password":

            return (
                "❌ Password must contain at least 6 characters."
            );


        case "auth/operation-not-allowed":

            return (
                "❌ Email/password authentication is " +
                "not enabled in Firebase."
            );


        // ====================================================
        // LOGIN
        // ====================================================

        case "auth/invalid-credential":

            return (
                "❌ Incorrect email or password."
            );


        case "auth/user-not-found":

            return (
                "❌ No account was found with this email."
            );


        case "auth/wrong-password":

            return (
                "❌ Incorrect password."
            );


        case "auth/user-disabled":

            return (
                "❌ This account has been disabled."
            );


        case "auth/too-many-requests":

            return (
                "❌ Too many login attempts. " +
                "Please try again later."
            );


        case "auth/network-request-failed":

            return (
                "❌ Network error. " +
                "Please check your internet connection."
            );


        // ====================================================
        // FIRESTORE
        // ====================================================

        case "permission-denied":

        case "firestore/permission-denied":

            return (
                "❌ Firestore permission denied. " +
                "Check your Firestore Security Rules."
            );


        default:

            return (
                "❌ " +
                (
                    error.message ||
                    "Something went wrong."
                )
            );

    }

}


// ============================================================
// SIGN UP
// ============================================================

if (signupForm) {

    console.log(
        "SIGNUP PAGE DETECTED"
    );


    signupForm.addEventListener(
        "submit",
        async function (event) {

            event.preventDefault();

            console.log(
                "SIGNUP FORM SUBMITTED"
            );


            const firstNameInput =
                document.getElementById(
                    "firstName"
                );


            const lastNameInput =
                document.getElementById(
                    "lastName"
                );


            const emailInput =
                document.getElementById(
                    "signupEmail"
                );


            const passwordInput =
                document.getElementById(
                    "signupPassword"
                );


            const message =
                document.getElementById(
                    "signupMessage"
                );


            const button =
                document.getElementById(
                    "signupButton"
                );


            // =================================================
            // SAFETY CHECK
            // =================================================

            if (
                !firstNameInput ||
                !lastNameInput ||
                !emailInput ||
                !passwordInput
            ) {

                showMessage(
                    message,
                    "❌ Signup form is incomplete."
                );

                return;

            }


            // =================================================
            // GET VALUES
            // =================================================

            const firstName =
                firstNameInput.value.trim();


            const lastName =
                lastNameInput.value.trim();


            const email =
                emailInput.value
                    .trim()
                    .toLowerCase();


            const password =
                passwordInput.value;


            // =================================================
            // VALIDATION
            // =================================================

            if (
                !firstName ||
                !lastName ||
                !email ||
                !password
            ) {

                showMessage(
                    message,
                    "❌ Please complete all fields."
                );

                return;

            }


            if (password.length < 6) {

                showMessage(
                    message,
                    "❌ Password must contain at least 6 characters."
                );

                return;

            }


            // =================================================
            // START LOADING
            // =================================================

            setButtonLoading(
                button,
                true,
                "Create Account"
            );


            showMessage(
                message,
                "",
                "success"
            );


            try {

                console.log(
                    "Creating Firebase account..."
                );


                // =================================================
                // CREATE ACCOUNT
                // =================================================

                const userCredential =
                    await createUserWithEmailAndPassword(
                        auth,
                        email,
                        password
                    );


                const user =
                    userCredential.user;


                console.log(
                    "ACCOUNT CREATED:",
                    user.uid
                );


                // =================================================
                // SAVE USER PROFILE
                // =================================================

                await setDoc(
                    doc(
                        db,
                        "users",
                        user.uid
                    ),
                    {

                        uid:
                            user.uid,

                        firstName:
                            firstName,

                        lastName:
                            lastName,

                        fullName:
                            `${firstName} ${lastName}`,

                        email:
                            email,

                        createdAt:
                            serverTimestamp()

                    }
                );


                console.log(
                    "USER PROFILE SAVED"
                );


                // =================================================
                // IMPORTANT
                // LOG THE NEW USER OUT
                // =================================================

                await signOut(
                    auth
                );


                console.log(
                    "USER SIGNED OUT AFTER SIGNUP"
                );


                // =================================================
                // SUCCESS MESSAGE
                // =================================================

                showMessage(
                    message,
                    "✅ Account created successfully! Redirecting to login...",
                    "success"
                );


                // =================================================
                // REDIRECT TO LOGIN
                // =================================================

                setTimeout(
                    function () {

                        window.location.href =
                            "login.html";

                    },
                    1000
                );


            } catch (error) {

                console.error(
                    "SIGNUP ERROR:",
                    error
                );


                showMessage(
                    message,
                    getFirebaseError(
                        error
                    )
                );


            } finally {

                setButtonLoading(
                    button,
                    false,
                    "Create Account"
                );

            }

        }
    );

}


// ============================================================
// LOGIN
// ============================================================

if (loginForm) {

    console.log(
        "LOGIN PAGE DETECTED"
    );


    loginForm.addEventListener(
        "submit",
        async function (event) {

            event.preventDefault();

            console.log(
                "LOGIN FORM SUBMITTED"
            );


            const emailInput =
                document.getElementById(
                    "loginEmail"
                );


            const passwordInput =
                document.getElementById(
                    "loginPassword"
                );


            const message =
                document.getElementById(
                    "loginMessage"
                );


            const button =
                document.getElementById(
                    "loginButton"
                );


            // =================================================
            // SAFETY CHECK
            // =================================================

            if (
                !emailInput ||
                !passwordInput
            ) {

                showMessage(
                    message,
                    "❌ Login form is incomplete."
                );

                return;

            }


            // =================================================
            // GET VALUES
            // =================================================

            const email =
                emailInput.value
                    .trim()
                    .toLowerCase();


            const password =
                passwordInput.value;


            // =================================================
            // VALIDATION
            // =================================================

            if (
                !email ||
                !password
            ) {

                showMessage(
                    message,
                    "❌ Please enter your email and password."
                );

                return;

            }


            // =================================================
            // START LOADING
            // =================================================

            setButtonLoading(
                button,
                true,
                "Login"
            );


            showMessage(
                message,
                "",
                "success"
            );


            try {

                console.log(
                    "AUTHENTICATING USER..."
                );


                // =================================================
                // REAL FIREBASE LOGIN
                // =================================================

                const userCredential =
                    await signInWithEmailAndPassword(
                        auth,
                        email,
                        password
                    );


                const user =
                    userCredential.user;


                console.log(
                    "LOGIN SUCCESS:",
                    user.uid
                );


                // =================================================
                // SUCCESS
                // =================================================

                showMessage(
                    message,
                    "✅ Login successful! Opening dashboard...",
                    "success"
                );


                // =================================================
                // GO TO DASHBOARD
                // =================================================

                setTimeout(
                    function () {

                        window.location.href =
                            "dashboard.html";

                    },
                    700
                );


            } catch (error) {

                console.error(
                    "LOGIN ERROR:",
                    error
                );


                showMessage(
                    message,
                    getFirebaseError(
                        error
                    )
                );


            } finally {

                setButtonLoading(
                    button,
                    false,
                    "Login"
                );

            }

        }
    );

}


// ============================================================
// IMPORTANT AUTH STATE CHECK
// ============================================================
//
// DO NOT automatically redirect from login.html to dashboard.
// The user must explicitly press Login and successfully
// authenticate first.
//
// This prevents the login page from behaving like an automatic
// dashboard redirect.
// ============================================================

if (
    loginForm ||
    signupForm
) {

    onAuthStateChanged(
        auth,
        function (user) {

            console.log(
                "AUTH STATE:",
                user
                    ? user.email
                    : "NOT LOGGED IN"
            );

            // --------------------------------------------------
            // IMPORTANT:
            // We intentionally DO NOT redirect here.
            // --------------------------------------------------

        }
    );

}


console.log(
    "AUTH.JS INITIALIZED SUCCESSFULLY"
);