import { auth, db } from "./firebase.js";

import {
    createUserWithEmailAndPassword,
    signInWithEmailAndPassword,
    signOut,
    onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-auth.js";

import {
    doc,
    setDoc,
    getDoc,
    serverTimestamp
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore.js";


// ======================================================
// ELEMENTS
// ======================================================

const authPage = document.getElementById("authPage");
const dashboardPage = document.getElementById("dashboardPage");

const registerForm = document.getElementById("registerForm");
const loginForm = document.getElementById("loginForm");

const registerButton = document.getElementById("registerButton");
const loginButton = document.getElementById("loginButton");
const logoutButton = document.getElementById("logoutButton");

const showLogin = document.getElementById("showLogin");
const showRegister = document.getElementById("showRegister");

const authMessage = document.getElementById("authMessage");


// ======================================================
// HELPER - MESSAGE
// ======================================================

function showMessage(message, type = "normal") {

    authMessage.textContent = message;

    if (type === "success") {
        authMessage.style.color = "green";
    }

    if (type === "error") {
        authMessage.style.color = "red";
    }

    if (type === "normal") {
        authMessage.style.color = "";
    }
}


// ======================================================
// SHOW LOGIN
// ======================================================

showLogin.addEventListener("click", function () {

    registerForm.classList.add("hidden");

    loginForm.classList.remove("hidden");

    showMessage("");

});


// ======================================================
// SHOW REGISTER
// ======================================================

showRegister.addEventListener("click", function () {

    loginForm.classList.add("hidden");

    registerForm.classList.remove("hidden");

    showMessage("");

});


// ======================================================
// CREATE ACCOUNT
// ======================================================

registerButton.addEventListener("click", async function () {

    console.log("CREATE ACCOUNT BUTTON CLICKED");

    const firstName =
        document.getElementById("firstName").value.trim();

    const lastName =
        document.getElementById("lastName").value.trim();

    const email =
        document.getElementById("registerEmail").value.trim();

    const password =
        document.getElementById("registerPassword").value;


    // -----------------------------------------------
    // VALIDATION
    // -----------------------------------------------

    if (firstName === "") {
        showMessage("Please enter your first name.", "error");
        return;
    }

    if (lastName === "") {
        showMessage("Please enter your last name.", "error");
        return;
    }

    if (email === "") {
        showMessage("Please enter your email.", "error");
        return;
    }

    if (password === "") {
        showMessage("Please enter a password.", "error");
        return;
    }

    if (password.length < 6) {
        showMessage(
            "Password must contain at least 6 characters.",
            "error"
        );
        return;
    }


    try {

        // Disable button
        registerButton.disabled = true;

        registerButton.textContent = "Creating account...";


        console.log("Creating Firebase Authentication account...");


        // -----------------------------------------------
        // CREATE AUTH ACCOUNT
        // -----------------------------------------------

        const userCredential =
            await createUserWithEmailAndPassword(
                auth,
                email,
                password
            );


        const user = userCredential.user;


        console.log("Firebase user created:");
        console.log(user.uid);


        // -----------------------------------------------
        // SAVE USER PROFILE TO FIRESTORE
        // -----------------------------------------------

        await setDoc(
            doc(db, "users", user.uid),
            {
                uid: user.uid,

                firstName: firstName,

                lastName: lastName,

                fullName: `${firstName} ${lastName}`,

                email: email,

                createdAt: serverTimestamp()
            }
        );


        console.log("User profile saved to Firestore");


        // -----------------------------------------------
        // SUCCESS
        // -----------------------------------------------

        alert(
            `Account created successfully!\n\nWelcome ${firstName}!`
        );


        showMessage(
            "Account created successfully! Please log in.",
            "success"
        );


        // -----------------------------------------------
        // SIGN OUT
        // -----------------------------------------------

        await signOut(auth);


        // -----------------------------------------------
        // CLEAR REGISTER FORM
        // -----------------------------------------------

        document.getElementById("firstName").value = "";

        document.getElementById("lastName").value = "";

        document.getElementById("registerEmail").value = "";

        document.getElementById("registerPassword").value = "";


        // -----------------------------------------------
        // SHOW LOGIN FORM
        // -----------------------------------------------

        registerForm.classList.add("hidden");

        loginForm.classList.remove("hidden");


        // -----------------------------------------------
        // PUT EMAIL INTO LOGIN
        // -----------------------------------------------

        document.getElementById("loginEmail").value = email;

        document.getElementById("loginPassword").value = "";


    } catch (error) {

        console.error("CREATE ACCOUNT ERROR:", error);


        let message = "Something went wrong.";


        switch (error.code) {

            case "auth/email-already-in-use":
                message = "This email already has an account.";
                break;

            case "auth/invalid-email":
                message = "Please enter a valid email address.";
                break;

            case "auth/weak-password":
                message = "Password is too weak. Use at least 6 characters.";
                break;

            case "auth/operation-not-allowed":
                message =
                    "Email/password login is not enabled in Firebase.";
                break;

            case "auth/network-request-failed":
                message =
                    "Network error. Check your internet connection.";
                break;

            case "permission-denied":
                message =
                    "Firebase Firestore permission denied.";
                break;

            default:
                message =
                    `${error.code}: ${error.message}`;
        }


        showMessage(message, "error");


    } finally {

        registerButton.disabled = false;

        registerButton.textContent = "Create Account";

    }

});


// ======================================================
// LOGIN
// ======================================================

loginButton.addEventListener("click", async function () {

    console.log("LOGIN BUTTON CLICKED");


    const email =
        document.getElementById("loginEmail").value.trim();

    const password =
        document.getElementById("loginPassword").value;


    if (email === "") {

        showMessage(
            "Please enter your email.",
            "error"
        );

        return;
    }


    if (password === "") {

        showMessage(
            "Please enter your password.",
            "error"
        );

        return;
    }


    try {

        loginButton.disabled = true;

        loginButton.textContent = "Logging in...";


        const userCredential =
            await signInWithEmailAndPassword(
                auth,
                email,
                password
            );


        console.log(
            "LOGIN SUCCESS:",
            userCredential.user.uid
        );


        showMessage(
            "Login successful!",
            "success"
        );


        // onAuthStateChanged will
        // automatically open dashboard


    } catch (error) {

        console.error("LOGIN ERROR:", error);


        let message = "Login failed.";


        switch (error.code) {

            case "auth/invalid-credential":
                message =
                    "Incorrect email or password.";
                break;

            case "auth/user-not-found":
                message =
                    "No account exists with this email.";
                break;

            case "auth/wrong-password":
                message =
                    "Incorrect password.";
                break;

            case "auth/invalid-email":
                message =
                    "Please enter a valid email.";
                break;

            case "auth/too-many-requests":
                message =
                    "Too many attempts. Please try again later.";
                break;

            default:
                message =
                    `${error.code}: ${error.message}`;
        }


        showMessage(message, "error");


    } finally {

        loginButton.disabled = false;

        loginButton.textContent = "Login";

    }

});


// ======================================================
// LOGOUT
// ======================================================

logoutButton.addEventListener("click", async function () {

    try {

        await signOut(auth);

        console.log("User logged out.");

    } catch (error) {

        console.error(
            "LOGOUT ERROR:",
            error
        );

    }

});


// ======================================================
// AUTH STATE
// ======================================================

onAuthStateChanged(auth, async function (user) {

    console.log(
        "AUTH STATE:",
        user ? user.email : "Not logged in"
    );


    if (user) {

        // -----------------------------------------------
        // SHOW DASHBOARD
        // -----------------------------------------------

        authPage.classList.add("hidden");

        dashboardPage.classList.remove("hidden");


        // -----------------------------------------------
        // LOAD FIREBASE PROFILE
        // -----------------------------------------------

        await loadProfile(user.uid);


    } else {

        // -----------------------------------------------
        // SHOW LOGIN / REGISTER
        // -----------------------------------------------

        dashboardPage.classList.add("hidden");

        authPage.classList.remove("hidden");

    }

});


// ======================================================
// LOAD USER PROFILE
// ======================================================

async function loadProfile(uid) {

    try {

        console.log(
            "Loading profile:",
            uid
        );


        const profileRef =
            doc(db, "users", uid);


        const profileSnapshot =
            await getDoc(profileRef);


        if (!profileSnapshot.exists()) {

            console.warn(
                "No Firestore profile found."
            );

            return;
        }


        const data =
            profileSnapshot.data();


        console.log(
            "PROFILE DATA:",
            data
        );


        // -----------------------------------------------
        // WELCOME
        // -----------------------------------------------

        document.getElementById(
            "welcomeMessage"
        ).textContent =
            `Hi ${data.firstName} 👋`;


        // -----------------------------------------------
        // PROFILE NAME
        // -----------------------------------------------

        document.getElementById(
            "profileName"
        ).textContent =
            `${data.firstName} ${data.lastName}`;


        // -----------------------------------------------
        // PROFILE EMAIL
        // -----------------------------------------------

        document.getElementById(
            "profileEmail"
        ).textContent =
            data.email;


        // -----------------------------------------------
        // CHATBOT GREETING
        // -----------------------------------------------

        const botGreeting =
            document.getElementById(
                "botGreeting"
            );


        if (botGreeting) {

            botGreeting.textContent =
                `Hi ${data.firstName} 👋 I'm your Financial Advisor. How can I help you today?`;

        }


    } catch (error) {

        console.error(
            "LOAD PROFILE ERROR:",
            error
        );

    }

}