// =====================================================
// FIREBASE CONFIGURATION
// =====================================================

import { initializeApp } from "https://www.gstatic.com/firebasejs/12.1.0/firebase-app.js";

import {
    getAuth
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-auth.js";

import {
    getFirestore
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore.js";

import {
    getStorage
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-storage.js";


// =====================================================
// FIREBASE CONFIG
// =====================================================

const firebaseConfig = {

    apiKey: "AIzaSyBXb8-PGwJ9JOmuYUJ9gNC6QOE-SO5d13M",

    authDomain:
        "financial-advisor-de73e.firebaseapp.com",

    projectId:
        "financial-advisor-de73e",

    storageBucket:
        "financial-advisor-de73e.firebasestorage.app",

    messagingSenderId:
        "711402363073",

    appId:
        "1:711402363073:web:fa03f596d5771fca0b5c40",

    measurementId:
        "G-RGNG7YHLSF"
};


// =====================================================
// INITIALIZE FIREBASE
// =====================================================

const app = initializeApp(firebaseConfig);


// =====================================================
// FIREBASE SERVICES
// =====================================================

export const auth = getAuth(app);

export const db = getFirestore(app);

export const storage = getStorage(app);